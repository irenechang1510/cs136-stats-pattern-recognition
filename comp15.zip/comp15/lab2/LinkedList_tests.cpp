/*
 * A testing file for your Linked List class that uses the unit_test framework
 *
*/
 
#include <iostream>
#include "LinkedList.h"
#include "Planet.h"


// An example test - see Lab01 for more information re: testing
void ll_constructor_test0(){
    LinkedList list;
}