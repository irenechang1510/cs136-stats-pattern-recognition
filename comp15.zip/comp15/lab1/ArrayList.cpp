/*
 * 
 * ArrayList.cpp
 * Matt Russell && Matt Champlin
 * COMP15 lab 1
 * 1/6/2021
 *   
 * Function definitions for the ArrayList class
 *   
 * TODO: fill in functions!
 *
 */
#include "ArrayList.h"

using namespace std;

/* 
 * name:      ArrayList default constructor
 * purpose:   initialize an empty ArrayList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 (also updates capacity and data array)
 */
ArrayList::ArrayList() {
    numItems = 0;
    capacity = 10;
    data = nullptr;
}

/* 
 * name:      ArrayList destructor
 * purpose:   free memory associated with the ArrayList 
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by Arraylist instances
 */
ArrayList::~ArrayList() {
    delete [] data;
}

/* 
 * name:      size
 * purpose:   determine the number of items in the ArrayList
 * arguments: none
 * returns:   number of elements currently stored in the ArrayList
 * effects:   none
 */
int ArrayList::size() {
    return this->numItems;
}

/* 
 * name:      isEmpty
 * purpose:   determines if the ArrayList is empty or not
 * arguments: none
 * returns:   true if ArrayList contains no elements, false otherwise
 * effects:   none 
 */
bool ArrayList::isEmpty() {
    if(numItems == 0){
      return true;
    }
    return false;
}

/* 
 * name:      print
 * purpose:   prints the contents of the ArrayList to cout
 * arguments: none
 * returns:   none
 * effects:   prints on cout
 */
void ArrayList::print() {
    if (numItems == 0) {
        std::cout << "[]" << std::endl;
        return;
    }
    std::cout << "[";
    // TODO: Complete the rest of the print function by printing each element
    //       of the ArrayList to cout. The format should look like:
    //       [1, 2, 3] for an ArrayList of 3 ints whose values are 1, 2 and 3
    //       We've given you the opening and closing braces. Fill in the rest!
    for (int i = 0; i < numItems; i++){
      cout << *(data+i) << ",";
    }
    std::cout << "]" << std::endl;
}

/* 
 * name:      pushAtBack
 * purpose:   push the provided integer into the back of the ArrayList
 * arguments: an integer to add to the back of the list
 * returns:   none
 * effects:   increases num elements of ArrayList by 1, 
 *            adds element to list
 */
void ArrayList::pushAtBack(int elem) {
    if(numItems == capacity){
      capacity *= 2;
    }
    data[numItems] = elem;
}

/* 
 * name:      popFromBack
 * purpose:   remove the last item from the ArrayList
 * arguments: none
 * returns:   none
 * effects:   decreases num items of ArrayList by 1
 *            removes the last item from the list
 */
void ArrayList::popFromBack() {
    
}

/* 
 * name:      find - JFFE
 * purpose:   determine if the provided integer is within the ArrayList
 * arguments: an integer to find
 * returns:   returns true if x is in the ArrayList, false otherwise
 * effects:   none
 */
bool ArrayList::find(int to_find) {
    
}




