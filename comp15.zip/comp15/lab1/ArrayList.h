/*
 * ArrayList.h
 * Matt Russell && Matt Champlin
 * COMP15 lab 1
 * 1/6/2021
 *
 * This is a class declaration for an ArrayList for lab0.
 *
 * TODO: complete the file!
 */
#ifndef ARRAYLIST_H
#define ARRAYLIST_H

#include<iostream>
#include<string>

class ArrayList {
    public:
        ArrayList();
        ~ArrayList();
        
        void pushAtBack(int elem);
        void popFromBack();
        bool isEmpty();
        void print();

        int  size();
            
        // JFFE! Write a find function that returns true if a given integer is
        // in the ArrayList, and false if not.
        bool find(int to_find);

    private:
        int numItems;
        int capacity;
        int *data;
        // helper function for changing the capacity of the ArrayList
        void expand();

};

#endif
