/* 
 * CharLinkedList.cpp
 * 
 * COMP 15 homework 1
 * by C.R. Calabrese, January 2021
 * edited by Irene Chang, Feb 2021
 * 
 * Stores characters in a certain order. It imitates some functions of the
 * C++ string. 
 * 
 * NOTE: This is implemented using a doubly-linked list. It is not circular
 *       and does not have a "back" pointer.
 */

#include "CharLinkedList.h"

// for the print function
#include <iostream>

using namespace std;

/* Purpose: initializes an empty CharLinkedList */
CharLinkedList::CharLinkedList()
{
    front = nullptr;
    len  = 0;
}

/*    Purpose: initializes a CharLinkedList containing one character
 * Parameters: the character that should be stored in the new list
 */
CharLinkedList::CharLinkedList(char c)
{
    Node *newNode = new Node;
    
    newNode->data = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    
    front = newNode;
    len = 1;
    
}

/*    Purpose: initializes a CharLinkedList containing all of the specified 
 *             characters, in the given order
 * Parameters: An array (in order) of characters to be stored in the list;
 *             the length of the given array (as an int)
 */
CharLinkedList::CharLinkedList(char *arr, int size)
{   
    // start with empty list
    len = 0;
    front = nullptr;
    
    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/* Purpose: copy constructor -- creates a list with the same information as
 *          the one passed in
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) 
{
    // start with empty list
    len = 0;
    front = nullptr;
    
    // push each item from the other list onto this one
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
}

/* Purpose: destructor -- frees all memory associated with the list */
CharLinkedList::~CharLinkedList()
{
    Node *curr = front;
    while (curr != nullptr){
        curr = curr->next;
        delete front;
        front = curr; 
    }
    
}

/* Purpose: assignment operator -- makes the current list contain the same
 *          information as the one on the right hand side
 */
CharLinkedList &CharLinkedList::operator =(const CharLinkedList &rhs) 
{
    if (this != &rhs) {
        clear(); // clear the current list
        
        // add each element from the other list into this one
        for (int i = 0; i < rhs.size(); i++) {
            pushAtBack(rhs.elementAt(i));
        }
    }
    return *this;
}

/* isEmpty
 *    Purpose: Check if the list is empty
 * Parameters: none
 *    Returns: a boolean -- true if the list is empty, false if it isn't
 */
bool CharLinkedList::isEmpty() const 
{
    return front == nullptr;
}

/* size
 *    Purpose: Get the number of characters being stored in the list
 * Parameters: none
 *    Returns: The number of characters currently stored in the list, as an
 *             int (will never be negative)
 */
int CharLinkedList::size() const 
{
    return len;
}

/* first
 *    Purpose: Get the first element in the list.
 * Parameters: none
 *    Returns: The first element in the list, as a char.
 * 
 *       Note: Prints an error message and exits if the list is empty.
 */
char CharLinkedList::first() const 
{
    if (isEmpty())
    {
      cerr << "Cannot get the first element of an empty list" << endl;
      exit(EXIT_FAILURE);
    }
    
    return front->data;
}

/* last
 *    Purpose: Get the last element in the list.
 * Parameters: none
 *    Returns: The last element in the list, as a char.
 * 
 *       Note: Prints an error message and exits if the list is empty.
 */
char CharLinkedList::last() const 
{
    if (isEmpty())
    {
        cerr << "Cannot get the last element of an empty list" << endl;
        exit(EXIT_FAILURE);
    }
    
    Node *curr = front;
    
    
    while (curr->next != nullptr){
        curr = curr->next;
    }
  
    return curr->data;
}

/* elementAt
 *    Purpose: Get the character at a given position.
 * Parameters: The index to be accessed, as an int. Should be in bounds; in 
 *             other words, should be in the range [0, size() )
 *    Returns: The element at the specified index, as a char
 */
char CharLinkedList::elementAt(int idx) const
{
    if (idx < 0 or idx >= size()){
        cerr << "index " << idx << " not in range [0.." << size() << ")"
             << endl;
        exit(EXIT_FAILURE);
    }
    
    Node *temp = front;
    
    for (int i = 0; i < idx; i++){
        temp = temp->next;
    }
    
    return temp->data;
}

/* print
 *    Purpose: Prints the list to the terminal (cout)
 * Parameters: None
 *    Returns: None
 */
void CharLinkedList::print() const
{
    cout << "[CharLinkedList of size " << size() <<  " <<";

    Node *temp = front;
    
    for (int i = 0; i < size(); i++) {
            cout << temp->data;
            temp = temp->next;
    }

    cout << ">>]" << endl;
}

/* clear
 *    Purpose: Makes the list empty
 * Parameters: None
 *    Returns: None
 */
void CharLinkedList::clear() 
{    
    //pop until there is no more element in the list
    while (size() > 0)
    {
        popFromFront();
    }
    
}

/* pushAtBack
 *    Purpose: Adds a character to the back of the list
 * Parameters: The character to be added to the list
 *    Returns: None
 */
void CharLinkedList::pushAtBack(char c)
{
    Node *ptr = new Node;
    
    ptr->data = c;
    ptr->next = nullptr;
    ptr->prev = nullptr;
    
    if (front == nullptr){ // list is currently empty
        front = ptr;
        
    } else {
        Node *curr = front;
        
        //move to the last node
        while (curr->next != nullptr){
            curr = curr->next;
        }
        
        curr->next = ptr;
        ptr->prev = curr;
    }
    
    // update length
    len++;
    
}

/* pushAtFront
 *    Purpose: Adds a character to the front of the list
 * Parameters: The character to be added to the list
 *    Returns: None
 */
void CharLinkedList::pushAtFront(char c)
{
    Node *myptr = new Node;
    
    myptr->data = c;
    myptr->next = front;
    myptr->prev = nullptr;
    front = myptr;
    
    // update length
    len++;
}

/* insertAt
 *    Purpose: Adds a character to the list at a given position
 * Parameters: The character to be added to the list and the position at which
 *             it should be added. The position should be in-bounds, that is,
 *             in the range [0, size()]. Providing size() as the index will
 *             insert the character at the back of the list.
 *    Returns: None
 * 
 *      To-Do: Would be fun to figure out how to do this recursively -- prev
 *             pointer makes it a little more complicated
 */
void CharLinkedList::insertAt(char c, int idx)
{
    if (idx < 0 or idx > size()){
        cerr << "index " << idx << " not in range [0.." << size() << "]"
             << endl;
        exit(EXIT_FAILURE);
    }
    if (idx == len){
        pushAtBack(c); // if insert at the end, then same as pushAtBack
    } else if (idx == 0){
        pushAtFront(c); // if insert at the front, then same as pushAtFront
    } else {
        Node *curr = front;
        // go to one node before the node at index
        for (int i = 0; i < idx - 1; i++){
          curr = curr->next;
        }
        // create new node and link them together
        Node *insert = new Node;
        insert->data = c;
        insert->next = curr->next;
        curr->next = insert;
        insert->prev = curr;
        curr->next->prev = insert;
        
        // update length
        len++;
    }  
}

/* popFromFront
 *    Purpose: Removes the first element from the list
 * Parameters: None
 *    Returns: None
 *       Note: Prints an error message and exits if the list is empty
 */
void CharLinkedList::popFromFront()
{
    if (isEmpty()) {
        cerr << "Cannot pop from an empty list" << endl;
        exit(EXIT_FAILURE);
    }
    
    Node *curr = front;
    
    front = front->next;
    if (front != nullptr){
        front->prev = nullptr; 
    }
    delete curr;
    
    // update length
    len--;
}

/* popFromBack
 *    Purpose: Removes the last element from the list
 * Parameters: None
 *    Returns: None
 *       Note: Prints an error message and exits if the list is empty
 */
void CharLinkedList::popFromBack()
{
    if (isEmpty()) {
        cerr << "Cannot pop from an empty list" << endl;
        exit(EXIT_FAILURE);
    }
    if(size() == 1){
        clear();
    } else{
        Node *curr = front;
        
        while(curr->next->next != nullptr)
        {
            curr = curr->next;
        }
        delete curr->next;
        curr->next = nullptr;
        
        // update length
        len--;
    }
}

/* removeAt
 *    Purpose: Removes the element at a given index
 * Parameters: The position at which to remove an element, which should be the
 *             index of an element currently in the list; in other words,
 *             should be in the interval [0, size)
 *    Returns: None
 */
void CharLinkedList::removeAt(int idx)
{
    if (idx < 0 or idx >= size()) {
        cerr << "index " << idx << " not in range [0.." << size() << ")"
             << endl;
        exit(EXIT_FAILURE);
    }
    
    Node *curr = front;
    if (idx == 0){ 
        popFromFront(); // remove the first element = popfromfront
    } else if (idx == size() - 1){
        popFromBack(); // remove the last element = popfromback
    } else { 
        for (int i = 0; i < idx; i++){
            curr = curr->next;
        }
        Node *temp = curr;
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        delete temp;
        
        // update length
        len--;
    }  
}

/* replaceAt
 *    Purpose: Replaces the element at the given index with the given value
 * Parameters: A character to put in the list and the index of the
 *             element to replace. The index should be in-bounds, in the
 *             range [0, size() )
 *       Note: Prints an error message and exits if the index is out of bounds
 */
void CharLinkedList::replaceAt(char c, int idx)
{
    if (idx < 0 or idx >= size()) {
        cerr << "index " << idx << " not in range [0.." << size() << ")"
             << endl;
        exit(EXIT_FAILURE);
    }
    Node *temp = front;
    
    for (int i = 0; i < idx; i++){
        temp = temp->next;
    }
    
    temp->data = c;
}

/* concatenate
 *    Purpose: Adds the contents of a CharLinkedList to the back of the current 
 *             one.
 * Parameters: A CharLinkedList whose contents should be pushed to the back of 
 *             the current list. Will not be altered
 *    Returns: None
 */
void CharLinkedList::concatenate(const CharLinkedList &other)
{
    // make a deep copy
    CharLinkedList temp_list(other);
    
    // push every element of the other list to the back of the current list
    for (int i = 0; i < temp_list.size(); i++)
    {
        pushAtBack(other.elementAt(i));
    }
}
