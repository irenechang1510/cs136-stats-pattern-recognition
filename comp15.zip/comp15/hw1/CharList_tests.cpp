/* 
 * CharList_tests.cpp
 * 
 * COMP 15 homework 1
 * by C.R. Calabrese, January 2021
 * Edited by : Irene Chang, February, 2021
 * 
 * Uses Matt Russell's unit_test framework to test the CharArrayList and
 * CharLinkedList.
 * More information on this testing framework can be found at: (link to more 
 * information unit_test)
 */

#include <cassert>
#include "CharArrayList.h"
#include "CharLinkedList.h"

/********************************************************************\
*                       CHAR ARRAY LIST TESTS                        *
\********************************************************************/

/* default constructor test
 * Run the ArrayList default constructor to make sure there are no runtime
 * errors or memory leaks
 */
void default_constructor_AL()
{
    CharArrayList testArrayList;
}

/* one element constructor test
 * Run the ArrayList constructor for one element to make sure there are no 
 * runtime errors or memory leaks 
 */
void one_el_constructor_AL()
{
    CharArrayList testArrayList('c');
}

/* array constructor test
 * Run the ArrayList constructor for an array of char to make sure there are no 
 * runtime errors or memory leaks 
 */
void arr_el_constructor_AL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    
}

/* destructor test
 * Initialize different types of ArrayList to make sure there are no
 * runtime errors or memory leaks 
 */
void destructor_test_AL()
{
    CharArrayList testArrayList1;
    CharArrayList testArrayList2('c');
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList3(el, 5);
    
}

/* size AL test
 * Create multiple list and see if the size function returns the correct size
 */
void size_test_AL()
{
    CharArrayList testArrayList;
    assert(testArrayList.size() == 0);
    CharArrayList testArrayList2('c');
    assert(testArrayList2.size() == 1);
    testArrayList2.pushAtFront('d');
    assert(testArrayList2.size() == 2);
    testArrayList2.pushAtFront('d');
    assert(testArrayList2.size() == 3);
}

/* getCapacity test
 * test if the capacity of array list is updated correctly
 * Note: only for temporary testing, correct updating
 */
// void getCapacity_test()
// {
//     CharArrayList testArrayList('c');
//     assert(testArrayList.getCapacity() == 1);
//     testArrayList.pushAtBack('c');
//     assert(testArrayList.getCapacity() == 2);
//     testArrayList.pushAtBack('c');
//     assert(testArrayList.getCapacity() == 4);
//     testArrayList.pushAtBack('c');
//     testArrayList.pushAtBack('c');
//     assert(testArrayList.getCapacity() == 8);
//     testArrayList.popFromBack();
//     testArrayList.popFromBack();
//     testArrayList.popFromBack();
//     testArrayList.popFromBack();
//     assert(testArrayList.getCapacity() == 4);
// }

/* return first element test
 * Initialize different types of ArrayList and assert that the first element
 * matches what we expect.
 */
void first_test_AL()
{
    CharArrayList testArrayList1('c');
    assert(testArrayList1.first() == 'c');
    
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList2(el, 5);
    assert(testArrayList2.first() == 'a');
  
}

/* return first element fail test
 * Initialize an empty ArrayList and make sure the program prints a warning and
 * exits when e try to access the first element.
 */
// void first_test_fail_AL()
// {
//     CharArrayList testArrayList1;
//     testArrayList1.first();
// 
// }

/* return last element test
 * Initialize different types of ArrayList and assert that the last element
 * matches what we expect.
 */
void last_test_AL(){
    
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList1(el, 5);
    assert(testArrayList1.last() == 'e');
    
    CharArrayList testArrayList2('c');
    assert(testArrayList2.last() == 'c');
    
}

/* return first element fail test
 * Initialize an empty ArrayList and make sure the program prints a warning and
 * exits when e try to access the last element.
 * correct message
 */
// void last_test_fail_AL()
// {
//     CharArrayList testArrayList1;
//     testArrayList1.last();
// 
// }  

/* return element at an index test
 * Initialize different types of ArrayList and assert that the elements at a
 * specified indexes match what we expect.
 */
void elementAt_test_AL()
{
    CharArrayList testArrayList1('c');
    assert(testArrayList1.elementAt(0) == 'c');
    
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    assert(testArrayList.elementAt(0) == 'a');
    assert(testArrayList.elementAt(1) == 'b');
    assert(testArrayList.elementAt(2) == 'c');
    
}

/* elementAt fail test
 * Initialize an ArrayList and make sure the program prints a warning 
 * and exits when e try to access an element out of range.
 * correct message
 */
// void elementAt_fail_test_AL()
// {
//     CharArrayList testArrayList1('c');
//     testArrayList1.elementAt(1);
// 
// }

/* clear ArrayList test
 * Assert that any element in the ArrayList after clearing is null character
 */
void clear_test_AL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    testArrayList.clear();
    assert(testArrayList.isEmpty() == true);
    assert(testArrayList.size() == 0);
    testArrayList.print();
    
    CharLinkedList testLinkedList2('c');
    testLinkedList2.clear();
    
    // clear empty list
    CharLinkedList testLinkedList3;
    testLinkedList3.clear();
}

/* pushAtBack test
 * Add more char and assert that the last element of the ArrayList matches the 
 * newly added elements. Make sure the size is updated.
 */
void pushAtBack_test_AL() 
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    testArrayList.pushAtBack('f');
    assert(testArrayList.size() == 6);
    assert(testArrayList.last() == 'f');
    
    //from an empty list
    CharArrayList testArrayList1;
    testArrayList1.pushAtBack('f');
    assert(testArrayList1.last() == 'f');
    assert(testArrayList1.first() == 'f');
    assert(testArrayList1.size() == 1);
    
    // from list with 1 element
    CharArrayList testArrayList2('c');
    testArrayList2.pushAtBack('f');
    assert(testArrayList2.last() == 'f');
    assert(testArrayList2.size() == 2);
}

/* pushAtFront test
 * Add more char to the front and assert that the first element of the 
 * ArrayList matches the newly added elements. Make sure the size is updated.
 */
void pushAtFront_test_AL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    testArrayList.pushAtFront('f');
    assert(testArrayList.size() == 6);
    assert(testArrayList.first() == 'f');
    
    //from empty list
    CharArrayList testArrayList1;
    testArrayList1.pushAtFront('f');
    assert(testArrayList1.last() == 'f');
    assert(testArrayList1.first() == 'f');
    assert(testArrayList1.size() == 1);
    
    // from list with 1 element
    CharArrayList testArrayList2('c');
    testArrayList2.pushAtFront('f');
    testArrayList2.print();
    assert(testArrayList2.last() == 'c');
    assert(testArrayList2.size() == 2);
}

/* insert test
 * Add more char to random positions in the list and assert that the element 
 * at that position matches the newly added elements. 
 * Assert that the old element at any one position is correctly shifted
 * Make sure the size is updated.
 */
void insertAt_test_AL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    testArrayList.insertAt('z', 3);
    assert(testArrayList.size() == 6);
    assert(testArrayList.elementAt(3) == 'z');
    testArrayList.insertAt('h', 6);
    assert(testArrayList.size() == 7);
    testArrayList.print(); // print to see
    //assert(testArrayList.getCapacity() == 10);
    
    // insert into 1 element list
    CharArrayList testArrayList1('c');
    testArrayList1.insertAt('E', 1);
    testArrayList1.insertAt('D', 0);
    assert(testArrayList1.size() == 3);
    assert(testArrayList1.elementAt(1) == 'c');
    
    // insert into an empty list
    CharArrayList testArrayList2;
    testArrayList2.insertAt('a', 0);
    testArrayList2.print();
    assert(testArrayList2.size() == 1);
    assert(testArrayList2.elementAt(0) == 'a');
}

/* insertAt AL fail test
 * Initialize an ArrayList and make sure the program prints a warning 
 * and exits when e try to insert an element into an index out of range.
 * correct message
 */
// void insertAt_fail_test_AL()
// {
//     CharArrayList testArrayList('c');
//     testArrayList.insertAt('z', 5);
// }

/* replace test
 * Replace a char at random positions in the list and assert that the element 
 * at that position matches the new elements. 
 */
void replace_test_AL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharArrayList testArrayList(el, 5);
    testArrayList.replaceAt('z', 2);
    assert(testArrayList.elementAt(2) == 'z');
    assert(testArrayList.last() == 'e');
    assert(testArrayList.size() == 5);
    
    // list with 1 element
    CharArrayList testArrayList2('c');
    testArrayList2.replaceAt('d', 0);
}

/* replaceAt fail test
 * Initialize an ArrayList and make sure the program prints a warning 
 * and exits when e try to replace an element out of range.
 * correct message
 */
// void replaceAt_fail_test_AL()
// {
//     char el[] = {'a', 'b', 'c', 'd', 'e'};
//     CharArrayList testArrayList(el, 5);
//     testArrayList.replaceAt('d', 5);
// }

/* concatenate test
 * Concatenate a new Arraylist to the back of the current one and assert that 
 * the element at that position matches the new elements. 
 */
void concat_test_AL()
{
    char el[] = {'c', 'a', 't'};
    CharArrayList testArrayList(el, 3);
    char luv[] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharArrayList otherArrayList(luv, 8);
    
    testArrayList.concatenate(otherArrayList);
    testArrayList.print();
    assert(testArrayList.size() == 11);
    for (int i = 0; i < testArrayList.size(); i++)
    {
      if (i < 3)
      {
        assert(testArrayList.elementAt(i) == el[i]);
      } else {
        assert(testArrayList.elementAt(i) == luv[i-3]);
      }
    }
    
    // concat with itself
    CharArrayList newlist(el, 3);
    newlist.concatenate(newlist);
    newlist.print();
    
    // empty list concat other is the same as copy the second list
    CharArrayList newlist2;
    newlist2.concatenate(otherArrayList);
    newlist2.print();
}

/*******************************************************************\
*                      CHAR LINKED LIST TESTS                       *
\*******************************************************************/

/* default constructor test
 * Run the LinkedList default constructor to make sure there are no runtime
 * errors or memory leaks
 */
void default_constructor_LL()
{
    CharLinkedList testLinkedList;
}

/* one element constructor test
 * Run the LinkedList constructor for one element to make sure there are no 
 * runtime errors or memory leaks 
 */
void one_el_constructor_LL()
{
    CharLinkedList testLinkedList('c');
  
}

/* array constructor test
 * Run the LinkedList constructor for an array of char to make sure there are 
 * no runtime errors or memory leaks 
 */
void arr_el_constructor_LL()
{
    char el[] = {'a', 'b', 'c', 'd'};
    CharLinkedList testLinkedList(el, 4);
    
}

/* copy constructor test
 * Run the LinkedList constructor for an array of char to make sure there are 
 * no runtime errors or memory leaks 
 */
void copy_constructor_LL()
{
    char el[] = {'a', 'b'};
    CharLinkedList testLinkedList1(el, 2);
    CharLinkedList testLinkedList2(testLinkedList1);
    assert(testLinkedList2.size() == 2);
    
    testLinkedList2.pushAtFront('c');
    CharLinkedList testLinkedList3(testLinkedList2);
    assert(testLinkedList3.size() == 3);
    assert(testLinkedList3.first() == 'c');   
    
    // copy empty list
    CharLinkedList testLinkedList;
    CharLinkedList testLinkedList4(testLinkedList);
}

/* assignment operator test
 * Initialize a LinkedList, assign it a new list, and make sure it has the
 * information of the new list 
 */
void test_assignment_operator_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(el, 5);
    CharLinkedList list2('o');
    assert(list1.size() == 5);
    assert(list2.size() == 1); 
    list1.print();
    list1 = list2; // assign
    list2.print();
    assert(list1.size() == 1); // check size after assignment
    list1.print();
    list1 = list1; // assign to itself
    
}

/* destructor test
 * Initialize different types of LinkedList to make sure there are no
 * runtime errors or memory leaks 
 */
void destructor_test_LL()
{
    CharLinkedList testLinkedList1;
    CharLinkedList testLinkedList2('c');
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList3(el, 5);
    CharLinkedList testLinkedList4(testLinkedList1);
    CharLinkedList testLinkedList5(testLinkedList2);
    CharLinkedList testLinkedList6(testLinkedList3);
    CharLinkedList testLinkedList7(testLinkedList4);
    
}

/* isEmpty LL test
 * Create multiple lists of different sizes and assert if they are empty or not 
 */
 void isEmpty_LL_test()
 {
    CharLinkedList testLinkedList;
    assert(testLinkedList.isEmpty() == true);
    CharLinkedList testLinkedList2('c');
    assert(testLinkedList2.isEmpty() == false);
    testLinkedList2.popFromBack();
    assert(testLinkedList2.isEmpty() == true);
    testLinkedList.pushAtFront('d');
    testLinkedList.insertAt('r', 1);
    assert(testLinkedList.isEmpty() == false);
    testLinkedList.clear();
    assert(testLinkedList.isEmpty() == true);
    
 }
 
/* size LL test
 * Create multiple list and see if the size function returns the correct size
 */
void size_test_LL()
{
    CharLinkedList testLinkedList;
    assert(testLinkedList.size() == 0);
    CharLinkedList testLinkedList2('c');
    assert(testLinkedList2.size() == 1);
    testLinkedList2.pushAtFront('d');
    assert(testLinkedList2.size() == 2);
    testLinkedList2.pushAtFront('d');
    assert(testLinkedList2.size() == 3);
}

/* return first element test
 * Initialize different types of LinkedList and assert that the first element
 * matches what we expect.
 */
void first_test_LL()
{
    CharLinkedList testLinkedList1('c');
    assert(testLinkedList1.first() == 'c');
    
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList2(el, 5);
    assert(testLinkedList2.first() == 'a');
  
}

/* return first element fail test
 * Initialize an empty LinkedList and make sure the program prints a warning 
 * and exits when e try to access the first element.
 * correct message
 */
// void first_test_fail_LL()
// {
//     CharLinkedList testLinkedList1;
//     testLinkedList1.first();
// 
// }

/* return last element test
 * Initialize different types of LinkedList and assert that the last element
 * matches what we expect.
 */
void last_test_LL(){
    
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList1(el, 5);
    assert(testLinkedList1.last() == 'e');
    
    CharLinkedList testLinkedList2('c');
    assert(testLinkedList2.last() == 'c');
    
}

/* return last element fail test
 * Initialize an empty LinkedList and make sure the program prints a warning 
 * and exits when e try to access the last element.
 * correct message
 */
// void last_test_fail_LL()
// {
//     CharLinkedList testLinkedList1;
//     testLinkedList1.last();
// 
// }


/* return element at an index test
 * Initialize different types of LinkedList and assert that the elements at a
 * specified indexes match what we expect.
 */
void elementAt_test_LL()
{
    CharLinkedList testLinkedList1('c');
    assert(testLinkedList1.elementAt(0) == 'c');
    
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    assert(testLinkedList.elementAt(0) == 'a');
    assert(testLinkedList.elementAt(1) == 'b');
    assert(testLinkedList.elementAt(2) == 'c');
}

/* elementAt fail test
 * Initialize a LinkedList and make sure the program prints a warning 
 * and exits when e try to access an element out of range.
 * correct message
 */
// void elementAt_fail_test_LL()
// {
//     CharLinkedList testLinkedList1('c');
//     testLinkedList1.elementAt(1);
// 
// }

/* test the print function
 * Initialize linked lists and try to print out the elements to see if it 
 * matches what we expect
 */
void print_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.print();
    
    CharLinkedList testLinkedList2;
    testLinkedList2.print();
    
    CharLinkedList testLinkedList3('r');
    testLinkedList3.print();
}

/* clear LinkedList test
 * Assert that any element in the LinkedList after clearing is null character
 */
void clear_test_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.clear();
    assert(testLinkedList.isEmpty() == true);
    assert(testLinkedList.size() == 0);
    testLinkedList.print();
    
    CharLinkedList testLinkedList2('c');
    testLinkedList2.clear();
    
    // clear empty list
    CharLinkedList testLinkedList3;
    testLinkedList3.clear();
}

/* pushAtBack test
 * Add more char and assert that the last element of the LinkedList matches the 
 * newly added elements. Make sure the size is updated.
 */
void pushAtBack_test_LL() 
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.pushAtBack('f');
    assert(testLinkedList.size() == 6);
    assert(testLinkedList.last() == 'f');
    
    //from an empty list
    CharLinkedList testLinkedList1;
    testLinkedList1.pushAtBack('f');
    assert(testLinkedList1.last() == 'f');
    assert(testLinkedList1.first() == 'f');
    assert(testLinkedList1.size() == 1);
    
    // from list with 1 element
    CharLinkedList testLinkedList2('c');
    testLinkedList2.pushAtBack('f');
    assert(testLinkedList2.last() == 'f');
    assert(testLinkedList2.size() == 2);
}

/* pushAtFront test
 * Add more char to the front and assert that the first element of the 
 * LinkedList matches the newly added elements. Make sure the size is updated.
 */
void pushAtFront_test_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.pushAtFront('f');
    assert(testLinkedList.size() == 6);
    assert(testLinkedList.first() == 'f');
    
    // from empty list
    CharLinkedList testLinkedList1;
    testLinkedList1.pushAtFront('f');
    assert(testLinkedList1.last() == 'f');
    assert(testLinkedList1.first() == 'f');
    assert(testLinkedList1.size() == 1);
    
    // from list with 1 element
    CharLinkedList testLinkedList2('c');
    testLinkedList2.pushAtFront('f');
    assert(testLinkedList2.last() == 'c');
    assert(testLinkedList2.size() == 2);
}

/* insert test
 * Add more char to random positions in the list and assert that the element 
 * at that position matches the newly added elements. 
 * Assert that the old element at any one position is correctly shifted
 * Make sure the size is updated.
 */
void insertAt_test_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.insertAt('z', 3);
    assert(testLinkedList.size() == 6);
    assert(testLinkedList.elementAt(3) == 'z');
    testLinkedList.insertAt('h', 6);
    assert(testLinkedList.size() == 7);
    testLinkedList.print(); // print to see
    
    // insert into 1 element list
    CharLinkedList testLinkedList1('c');
    testLinkedList1.insertAt('E', 1);
    testLinkedList1.insertAt('D', 0);
    assert(testLinkedList1.size() == 3);
    assert(testLinkedList1.elementAt(1) == 'c');
    
    // insert into an empty list
    CharLinkedList testLinkedList2;
    testLinkedList2.insertAt('a', 0);
    testLinkedList2.print();
    assert(testLinkedList2.size() == 1);
    assert(testLinkedList2.elementAt(0) == 'a');
}

/* insertAt LL fail test
 * Initialize a LinkedList and make sure the program prints a warning 
 * and exits when e try to insert an element into an index out of range.
 * correct message
 */
// void insertAt_fail_test_LL()
// {
//     CharLinkedList testLinkedList('c');
//     testLinkedList.insertAt('z', 5);
// }

/* popFromFront LL test
 * Try to remove the front character and use print and assert to see if it 
 * matches what we expected
 */
void popFromFront_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.popFromFront();
    assert(testLinkedList.elementAt(0) == 'b');
    assert(testLinkedList.size() == 4);
    testLinkedList.print();
    
    // from list with 1 element
    CharLinkedList testLinkedList2('c');
    testLinkedList2.popFromFront();
    
}

/* popFront LL fail test
 * Initialize a LinkedList and make sure the program prints a warning 
 * and exits when e try to pop from an empty list;
 * correct message
 */
// void popFront_fail_test_LL()
// {
//     CharLinkedList testLinkedList;
//     testLinkedList.popFromFront();
// }

/* popFromBack LL test
 * Try to remove the back character and use print and assert to see if it 
 * matches what we expected
 */
void popFromBack_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    
    testLinkedList.popFromBack(); 
    assert(testLinkedList.size() == 4);
    
    // from list with 1 element
    CharLinkedList testLinkedList2('c');
    testLinkedList2.popFromBack();
    
    // should fail
    //assert(testLinkedList.elementAt(4) == 'e'); 
}

/* popBack LL fail test
 * Initialize a LinkedList and make sure the program prints a warning 
 * and exits when e try to pop from an empty list;
 * correct message
 */
// void popBack_fail_test_LL()
// {
//     CharLinkedList testLinkedList;
//     testLinkedList.popFromBack();
// }


/* remove test for linked list
 * create linked lists and remove an element at random, assert that the element
 * at that position is correct
 */
void removeAt_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    
    testLinkedList.removeAt(2);
    assert(testLinkedList.elementAt(2) == 'd');
    assert(testLinkedList.elementAt(3) == 'e');
    assert(testLinkedList.size() == 4);
    
    testLinkedList.removeAt(0);
    assert(testLinkedList.elementAt(0) == 'b');
    
    testLinkedList.removeAt(2);
    assert(testLinkedList.size() == 2);
    assert(testLinkedList.elementAt(1) == 'd');
    
    testLinkedList.removeAt(1);
    testLinkedList.removeAt(0);
    assert(testLinkedList.isEmpty());
}

/* removeAt fail test
 * Initialize a LinkedList and make sure the program prints a warning 
 * and exits when e try to remove an element out of range.
 * correct message
 */
// void removeAt_fail_test_LL()
// {
//     char el[] = {'a', 'b', 'c', 'd', 'e'};
//     CharLinkedList testLinkedList(el, 5);
//     testLinkedList.removeAt(5);
// 
//     // can't remove at empty list
//     CharLinkedList testLinkedList2;
//     testLinkedList2.removeAt(0);
// }

/* replace test
 * Replace a char at random positions in the list and assert that the element 
 * at that position matches the new elements. 
 */
void replace_test_LL()
{
    char el[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList testLinkedList(el, 5);
    testLinkedList.replaceAt('z', 2);
    assert(testLinkedList.elementAt(2) == 'z');
    assert(testLinkedList.last() == 'e');
    assert(testLinkedList.size() == 5);
    
    // list with 1 element
    CharLinkedList testLinkedList2('c');
    testLinkedList2.replaceAt('d', 0);
}

/* replaceAt fail test
 * Initialize a LinkedList and make sure the program prints a warning 
 * and exits when e try to replace an element out of range.
 * correct message
 */
// void replaceAt_fail_test_LL()
// {
//     char el[] = {'a', 'b', 'c', 'd', 'e'};
//     CharLinkedList testLinkedList(el, 5);
//     testLinkedList.replaceAt('d', 5);
// }

/* concatenate test
 * Concatenate a new Linkedlist to the back of the current one and assert that 
 * the element at that position matches the new elements. 
 */
void concat_test_LL()
{
    char el[] = {'c', 'a', 't'};
    CharLinkedList testLinkedList(el, 3);
    char luv[] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList otherLinkedList(luv, 8);
    
    testLinkedList.concatenate(otherLinkedList);
    testLinkedList.print();
    assert(testLinkedList.size() == 11);
    for (int i = 0; i < testLinkedList.size(); i++)
    {
      if (i < 3)
      {
        assert(testLinkedList.elementAt(i) == el[i]);
      } else {
        assert(testLinkedList.elementAt(i) == luv[i-3]);
      }
    }
    
    // concat with itself
    CharLinkedList newlist(el, 3);
    newlist.concatenate(newlist);
    newlist.print();
    
    // empty list concat other is the same as copy the second list
    CharLinkedList newlist2;
    newlist2.concatenate(otherLinkedList);
    newlist2.print();
}


