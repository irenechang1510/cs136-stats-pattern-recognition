/*
 * DatumStack_tests.cpp
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * Use unit_test framework to test DatumStack and the functions for the simple 
 * commands in RPNCalc. Some private functions are made temporarily public for 
 * testing.
 */

#include "DatumStack.h"
#include "RPNCalc.h"
#include "Datum.h"
#include <cassert>
#include <iostream>

using namespace std;

////////////////////// TEST FOR DATUMSTACK ////////////////////////////////////

// test for DatumStack constructor, make sure no runtime error or memory leaks
void test_default_constructor()
{
    DatumStack d;
}

// test for destructor with parameters being an array, make sure no runtime 
// error or memory leaks 
void test_param_constructor()
{
    Datum d1(1);
    Datum d2(2);
    Datum d3(3);
    Datum arr[3] = {d1, d2, d3};
    DatumStack s(arr, 3);
    Datum b1(true);
}

// test for the isEmpty function by initializing datumstack of different sizes
// and make sure the function returns the correct conclusion 
void test_isEmpty(){
    Datum d1(1);
    Datum d2(2);
    Datum d3(3);
    Datum arr[3] = {d1, d2, d3};
    DatumStack s(arr, 3);
    assert(s.isEmpty() == false);
    DatumStack s2;
    assert(s2.isEmpty() == true);
}

// test for the clear function in datumstack by initializing datumstacks with
// multiple elements and make sure the stack is empty after the call to clear
void test_clear(){
    Datum d1(1);
    Datum d2(2);
    Datum d3(3);
    Datum arr[3] = {d1, d2, d3};
    DatumStack s(arr, 3);
    assert(s.isEmpty() == false);
    s.clear();
    assert(s.isEmpty() == true);
}

// test for the size function in datumstack by initializing datumstacks of a
// certain size and make sure the function outputs the correct size
void test_size(){
    DatumStack s1;
    assert(s1.size() == 0);
    
    Datum d1(1);
    Datum arr1[1] = {d1};
    DatumStack s2(arr1, 1);
    assert(s2.size() == 1);
    
    Datum d2(2);
    Datum d3(3);
    Datum arr2[3] = {d1, d2, d3};
    DatumStack s3(arr2, 3);
    assert(s3.size() == 3);
}

// test the top function in datumstack by initializing datumstack with elements
// and see if the function return the correct top element. Test with an empty
// stack to make sure the program throws a runtime error
void test_top(){
    Datum d1(5);
    Datum d2(2);
    Datum d3(3);
    Datum arr[3] = {d1, d2, d3};
    DatumStack s(arr, 3);
    assert(s.size() == 3);
    assert(s.top().getInt() == 3);
    
    // should fail. Note: Correct message
    // DatumStack d;
    // d.top();
}

// test the pop function in datumstack by initializing datumstack with elements
// Pop each element off one at a time and check if size decreases by 1
// Test with an empty stack to make sure the program throws a runtime error. 
void test_pop(){
    Datum d1(5);
    Datum d2(2);
    Datum d3(3);
    Datum arr[3] = {d1, d2, d3};
    DatumStack s(arr, 3);
    assert(s.size() == 3);
    s.pop();
    assert(s.size() == 2);
    s.pop();
    assert(s.size() == 1);
    s.pop();
    assert(s.isEmpty() == true);
    
    // should fail. Note: Correct message
    // s.pop();
}

// test the push function in datumstack by initializing datumstack with 
// elements
// Firstly, push one new element onto the stack one at a time and check if size 
// increases by 1, then push multiple elements at a time and check if the size
// is correct
void test_push(){
    Datum d1(5);
    Datum d2(2);
    Datum d3(3);
    Datum arr[3] = {d1, d2, d3};
    DatumStack s;
    assert(s.size() == 0);
    s.push(d1);
    assert(s.size() == 1);
    s.push(d1);
    assert(s.size() == 2);
    s.push(d2);
    assert(s.size() == 3);
    s.push(d3);
    assert(s.size() == 4);
    s.push(d3);
    s.push(d3);
    s.push(d3);
    assert(s.size() == 7);
}

////////////////////// TEST FOR RPNCALC ///////////////////////////////////////

// test the integer command for rpncalc. Pass an integer as a string to the
// simple_command function, then check the size to make sure the int has been
// pushed to the stack. Invalid int-string should not be pushed to the stack
void add_int_command_test()
{
    RPNCalc r;
    r.simple_command("1");
    assert(r.getStackSize() == 1);
    r.simple_command("50");
    assert(r.getStackSize() == 2);
    r.simple_command("-100");
    assert(r.getStackSize() == 3);
    r.simple_command("cry");
    assert(r.getStackSize() == 3);
}

// test the is_operator function in rpncalc. Call the is_operator function on 
// various commands and make sure it only returns true for math operators 
void is_operator_test(){
    RPNCalc r;
    assert(r.is_operator("+") == true);
    assert(r.is_operator("h") == false);
    assert(r.is_operator("mod") == true);
    assert(r.is_operator("-") == true);
    assert(r.is_operator("*") == true);
    assert(r.is_operator("/") == true);
}

// test the is_compare function in rpncalc. Call the is_compare function on 
// various commands and make sure it only returns true for comparison operators 
void is_compare_test(){
    RPNCalc r;
    assert(r.is_compare(">") == true);
    assert(r.is_compare("h") == false);
    assert(r.is_compare("<=") == true);
    assert(r.is_compare("==") == true);
    assert(r.is_compare(">=") == true);
    assert(r.is_compare(">") == true);
}

// test the operate_math and calculate function. Initialize the integers on the
// stack and call different math operator, make sure the correct result is 
// pushed to the top of the stack after the execution. 
void operate_math_test()
{
    // plus
    RPNCalc r;
    r.simple_command("3");
    r.simple_command("5");
    r.operate_math("+");
    assert(r.getTop().getInt() == 8);
    // minus
    r.simple_command("17");
    r.simple_command("8");
    r.operate_math("-");
    assert(r.getTop().getInt() == 9);
    // multiply 
    r.simple_command("8");
    r.simple_command("7");
    r.operate_math("*");
    assert(r.getTop().getInt() == 56);
    // divide 
    r.simple_command("8");
    r.simple_command("2");
    r.operate_math("/");
    assert(r.getTop().getInt() == 4);
    r.simple_command("8");
    r.operate_math("/");
    assert(r.getTop().getInt() == 0);
    // mod
    r.simple_command("7");
    r.simple_command("8");
    r.operate_math("mod");
    assert(r.getTop().getInt() == 7);
}

// test the compare function. Initialize the integers on the stack and call 
// different comparison operator, make sure the correct result is pushed to the
// top of the stack after the execution 
// Note: split into 2 parts because of line limits
void compare_test_1()
{
    RPNCalc r;
    r.simple_command("3");
    r.simple_command("5");
    r.compare(">");
    assert(r.getTop().getBool() == false);
    
    r.simple_command("3");
    r.simple_command("5");
    r.compare("<");
    assert(r.getTop().getBool() == true);
    
    r.simple_command("5");
    r.simple_command("5");
    r.compare(">=");
    assert(r.getTop().getBool() == true);
    
    r.simple_command("7");
    r.simple_command("5");
    r.compare(">=");
    assert(r.getTop().getBool() == true);
}

// test the compare function. Initialize the integers on the stack and call 
// different comparison operator, make sure the correct result is pushed to the
// top of the stack after the execution 
// Note: split into 2 parts because of line limits
void compare_test_2()
{
    RPNCalc r;
    r.simple_command("5");
    r.simple_command("5");
    r.compare("<=");
    assert(r.getTop().getBool() == true);
    
    r.simple_command("7");
    r.simple_command("5");
    r.compare("<=");
    assert(r.getTop().getBool() == false);
    
    r.simple_command("10");
    r.simple_command("5");
    r.compare("==");
    assert(r.getTop().getBool() == false);
    
    r.simple_command("5");
    r.simple_command("5");
    r.compare("==");
    assert(r.getTop().getBool() == true);
}

// test the case where we apply operators on inputs that are not integers 
// Note: all of them should print out the error message.
void not_int_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("7");
    r.operate_math("-");
    
    r.simple_command("7");
    r.simple_command("#f");
    r.operate_math("+");
    
    r.simple_command("#t");
    r.simple_command("7");
    r.operate_math(">");
    
    r.simple_command("7");
    r.simple_command("#f");
    r.operate_math(">=");
}

// test the boolean-string input. Pass boolean to the simple_command function
// and make sure that the valid boolean is pushed onto the stack by checking
// if the size increments by 1
void add_true_false_test()
{
    RPNCalc r;
    r.simple_command("#t");
    assert(r.getStackSize() == 1);
    r.simple_command("#f");
    assert(r.getStackSize() == 2);
    r.simple_command("#t");
    assert(r.getStackSize() == 3);
    r.simple_command("t");
    assert(r.getStackSize() == 3);
}

// test the not function of RPNCalc by pushing boolean and non-boolean values 
// onto the stack and make sure the not function is only applied to the correct
// datum type.
void inverse_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("not");
    assert(r.getTop().getBool() == false);
    r.simple_command("not");
    assert(r.getTop().getBool() == true);
    // print out cerr but not crash the program
    r.simple_command("1");
    r.simple_command("not");
    // when the stack is empty 
    RPNCalc r2;
    r2.simple_command("not");
}

// test the print command of RPNCalc, make changes to the stack and make sure 
// what is printed out is the current top of the stack
void print_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("12345");
    r.simple_command("print");
    r.simple_command("gUYDJGDQUYTU");
    r.simple_command("print"); // should print 12345
    r.simple_command("0");
    r.simple_command("print");
    r.simple_command("#f");
    r.simple_command("print");
    // when the stack is empty 
    RPNCalc r2;
    r2.simple_command("print");
}

// test the clear command of RPNCalc by pushing different types of datum onto 
// the stack, then use clear and make sure the stack is empty after the clear 
// function
// Note: call on empty stack should print cerr and continue without crashing
void clear_command_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("12345");
    r.simple_command("33");
    assert(r.getStackSize() == 3);
    r.simple_command("clear");
    assert(r.getStackSize() == 0);
    
    //when stack is empty, should have no error
    RPNCalc r2;
    r2.simple_command("clear");
}

// test the drop command of RPNCalc by pushing datums onto the stack, then use
// drop on the stack and make sure the size decreases by 1 after every call
// as well as checking the top element of the stack
// Note: call on empty stack should print cerr and continue without crashing
void drop_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("12345");
    r.simple_command("33");
    assert(r.getStackSize() == 3);
    r.simple_command("drop");
    assert(r.getStackSize() == 2);
    assert(r.getTop().getInt() == 12345);
    
    // when the stack is empty
    RPNCalc r2;
    r2.simple_command("drop");
}

// test the drop command of RPNCalc by pushing datums onto the stack, then use
// drop on the stack and make sure the size increments by 1 after every call
// as well as checking the top element of the stack
// Note: call on empty stack should print cerr and continue without crashing
void dup_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("12345");
    r.simple_command("33");
    assert(r.getStackSize() == 3);
    r.simple_command("dup");
    assert(r.getStackSize() == 4);
    assert(r.getTop().getInt() == 33);
    
    // when the stack is empty
    RPNCalc r2;
    r2.simple_command("dup");
}

// test the drop command of RPNCalc by pushing datums onto the stack, then use
// drop on the stack and make sure the size stays the same after every call
// as well as checking the top element of the stack
// Note: call on empty stack should print cerr and continue without crashing
void swap_test()
{
    RPNCalc r;
    r.simple_command("#t");
    r.simple_command("12345");
    r.simple_command("33");
    assert(r.getStackSize() == 3);
    r.simple_command("swap");
    assert(r.getStackSize() == 3);
    assert(r.getTop().getInt() == 12345);
    r.simple_command("swap");
    assert(r.getTop().getInt() == 33);
    
    // when the stack is empty
    RPNCalc r2;
    r2.simple_command("swap");
}

// master execute test 1 
// after unit test individual function, I now test execute, which can make the
// call to all the command above. Also in this test, the interactions between
// different commands can be checked, including commands that produce errors
// and invalid commands
// Note: split into 2 parts because of line limits
void master_execute_test1()
{
    // simple command
    bool end = false;
    RPNCalc r;
    r.execute("12", &end, cin);
    //r.execute("+", &end); // error too few numbers
    r.execute("77", &end, cin);
    r.execute("+", &end, cin);
    assert(r.getTop().getInt() == 89); 
    r.execute("68", &end, cin);
    r.execute("mod", &end, cin);
    assert(r.getTop().getInt() == 21); 
    // r.execute("-", &end); // error too few numbers
    r.execute("10", &end, cin);
    r.execute("-", &end, cin);
    assert(r.getTop().getInt() == 11);
    r.execute("clear", &end, cin);
    //r.execute("drop", &end); // error empty stack
    
}

// master execute test 2 
// after unit test individual function, I now test execute, which can make the
// call to all the command above. Also in this test, the interactions between
// different commands can be checked, including commands that produce errors
// and invalid commands
// Note: split into 2 parts because of line limits
void master_execute_test2()
{
    RPNCalc r;
    bool end = false;
    r.execute("-50", &end, cin);
    r.execute("dup", &end, cin);
    assert(r.getStackSize() == 2);
    // r.execute("not", &end); // error not bool
    r.execute("#t", &end, cin);
    //r.execute("/", &end); // error not int
    r.execute("swap", &end, cin);
    assert(r.getTop().getInt() == -50);
    r.execute("drop", &end, cin);
    assert(r.getTop().getBool() == true);
    r.execute("not", &end, cin);
    assert(r.getStackSize() == 2);
    assert(r.getTop().getBool() == false);
    r.execute("print", &end, cin);
    // r.execute(">", &end); // error not int
    r.execute("5", &end, cin);
    r.execute("4", &end, cin);
    r.execute("<", &end, cin);
    assert(r.getTop().getBool() == false);
    assert(r.getStackSize() == 3);
    r.execute("clear", &end, cin);
    r.execute("print", &end, cin); 
    // invalid query 
    r.execute("Pi", &end, cin);
}

// if test
// this is the initial test for if command, also the only complex command that
// is tested in unit test. cerr messages are put in each if-else block to make
// sure that our conditions work and the program enters the right block. 
// After that, changes are made to the main function and so the test here is
// commented out
void if_test(){
    // RPNCalc r;
    // bool end = false;
    // r.simple_command("#t");
    // r.simple_command("12345");
    // r.simple_command("33");
    // // r.command_if(); // error falsecase not rstring
    // r.simple_command("#t");
    // r.complex_command("{ 1 2 + }");
    // // r.command_if(); // error truecase not rstring
    // // r.execute("string", &end); // error invalid command 
    // r.complex_command("{ 1 2 + }");
    // r.complex_command("{ 3 4 - }");
    // // r.command_if(); // error not boolean
    // r.simple_command("#f");
    // r.complex_command("{ 1 2 + }");
    // r.complex_command("{ 3 4 - }");
    // // r.command_if(); // should print out "true case"
    // // modify #t into #f 
    // r.command_if(); // should print out "false case"
    // r.command_if(); // should print error not rstring
}

