/*
 * DatumStack.cpp
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * One implementation of the DatumStack interface. DatumStack can be 
 * instantiated empty or from an array of Datum objects. All interactions with
 * DatumStack is through the the top of the stack (remove, add, access). 
 * Certain functions cannot be used with an empty stack.
 */

#include "DatumStack.h"
#include "Datum.h"
#include <vector>
#include <iostream>

using namespace std;

/* default constructor
 *   Purpose: initializes an empty DatumStack
 */
DatumStack::DatumStack(){
    stack_size = 0;
}

/* constructor for an array and array size
 *   Purpose: initializes a DatumStack froma Datum array of a particular size
 */
DatumStack::DatumStack(Datum arr[], int size){
    stack_size = size;
    for (int i = 0; i < size; i++){
        push(arr[i]);
    }
}

/* isEmpty
 *   Purpose: check if a DatumStack has any Datum
 * Parameter: none
 *    Return: a boolean value that is true if the stack is empty
 */
bool DatumStack::isEmpty(){
    return stack.size() == 0;
}

/* clear
 *   Purpose: clear all the Datums currently on the DatumStack
 * Parameter: none
 *    Return: none
 */
void DatumStack::clear(){
    stack.clear();
}

/* size
 *   Purpose: Access the size of the current stack
 * Parameter: none
 *    Return: an integer indicating the size of the current DatumStack
 */
int DatumStack::size(){
    return stack.size();
}

/* top
 *   Purpose: Access the size of the current stack
 * Parameter: none
 *    Return: the Datum at the top of the DatumStack
 *
 * Note: cannot use this function on an empty stack
 */
Datum DatumStack::top(){
    if (size() == 0){
        throw runtime_error("empty_stack");
    } 
    
    return stack.back();
}

/* pop
 *   Purpose: remove the topmost Datum of the current DatumStack
 * Parameter: none
 *    Return: none
 *
 * Note: cannot use this function on an empty stack
 */
void DatumStack::pop(){
    if (size() == 0){
        throw runtime_error("empty_stack");
    }
    stack.pop_back();
}

/* push
 *   Purpose: Add a Datum to the top of the current stack
 * Parameter: The Datum to be added to the stack
 *    Return: none
 */
void DatumStack::push(Datum d){
    stack.push_back(d);
}