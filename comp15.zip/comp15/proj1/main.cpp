/*
 * main.cpp
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * CalcYouLater is a simulation of the Reverse Polish Notation calculator. It 
 * initializes a stack that stores datum objects, which can be integers, 
 * operations, a file, or a series of all of the above and carry out the
 * command following the user's input.
 */

#include "DatumStack.h"
#include "Datum.h"
#include "RPNCalc.h"

int main()
{
    RPNCalc r;
    r.run();
    return 0;
}