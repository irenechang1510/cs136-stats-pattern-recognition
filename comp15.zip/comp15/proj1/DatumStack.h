/*
 * DatumStack.h
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * The interface of DatumStack class. The purpose of this class is to create a
 * stack that stores Datum, objects of class. DatumStack class contains 
 * functions for monitoring and querying the stack, in a way that supports the 
 * Reverse Polish Notation calculation 
 */
 
#ifndef __DATUMSTACK_H__
#define __DATUMSTACK_H__

#include "Datum.h"
#include <vector>

using namespace std;

class DatumStack {
    public:
        DatumStack();
        DatumStack(Datum arr[], int size);
        
        bool isEmpty();
        void clear();
        int size();
        Datum top();
        void pop();
        void push(Datum d);
        
    private:
        vector<Datum> stack;
        int stack_size;
        
};

#endif