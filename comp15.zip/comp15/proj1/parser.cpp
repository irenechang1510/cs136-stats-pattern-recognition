/*
 * parser.cpp
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * Purpose: Parse the characters together to form an RString
 */

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

//string parseRString(istream &input);

// for testing 
// int main(){
//     // read from a file
//     ifstream inf("test.txt");
//     string line;
//     getline(inf, line);
//     while (not inf.eof()){
//         stringstream str;
//         str << line;
//         cout << parseRString(str) << endl;
//         getline(inf, line);
//     }
// 
//     // passing in string stream
//     istringstream str2("1 { 3 } 5 }");
//     istringstream str3("1 { 3 4 + h { 6 7 8 g i } } 4 ");
//     cout << parseRString(str2) << endl; 
//     cout << parseRString(str3) << endl; 
// 
//     // passing in cin
//     cout << parseRString(cin) << endl;
//     return 0;
// }

/* 
 * parseRString
 *    Purpose: Read in the inputs and parse them into an RString expression
 * Parameters: an object of input stream
 *     Return: a string of characters from input parsed together 
 */
string parseRString(istream &input){ 
    string parse = "{ ";
    string temp_string;
    bool closed = false;
    int num_open = 1;
    int num_closed = 0;

    while (not input.fail() and not closed){
        input >> temp_string;
        if (temp_string == "{"){
            num_open++;
        } else if (temp_string == "}"){
            num_closed++;
        } 
        
        parse = parse + temp_string + " ";
        if (num_open == num_closed){
            closed = true;
        }
    }
    
    if (num_open != num_closed){
        return "Invalid rstring"; 
    } 
    return parse;
}
 