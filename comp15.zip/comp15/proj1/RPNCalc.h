/*
 * DatumStack.h
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * The interface of RPNCalc class. The purpose of this class is to perform the 
 * Reverse Polish Notation calculation. It accepts different commands and 
 * output the result under the hood, which can be seen with "print". Its input
 * can be one of the math operations, an series of command (rstring) or a file
 */
 
#ifndef __RPNCALC_H__
#define __RPNCALC_H__

#include "DatumStack.h"
#include "Datum.h"
#include <sstream>

class RPNCalc {
    public:
        RPNCalc();
        ~RPNCalc();
        
        void run();
        
    private:
        DatumStack d;
        bool command_is_int;
        
        // helpers for execute function
        void execute(string query, bool* end, istream &input);
        void complex_command(string query, bool* end, istream &input);
        void simple_command(string query);
        bool is_operator(string query);
        bool is_compare(string query);
        bool valid_command(string query);
        int getStackSize();
        
        // simple command functions and helper functions
        void operate_math(string query);
        void calculate(string query, int var0, int var1);
        void compare(string query);
        bool got_int(string s, int *resultp);
        void swap();
        void inverse();
        bool stack_is_empty();
        
        // more complex commands
        string parseRString(istream &input);
        void command_exec(bool *end);
        void command_file(bool *end);
        void command_if(bool *end, istream &input);
        
        // for testing 
        Datum getTop(); // for testing    
};

#endif