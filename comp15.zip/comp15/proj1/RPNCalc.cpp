/*
 * RPNCalc.cpp
 *
 * COMP 15 project 1
 * by Irene Chang, March 2021
 * 
 * One implementation of the RPNCalc interface. RPNCalc is instantiated empty. 
 * After instantiation, we can start using the calculator with the run function
 * which then process the commands and stores the values in a Datumstack 
 * structure.
 *
 * Note: If encountered error, the program will print out the message and 
 * continue to take in new command, rather than crash. The datum for the failed
 * commands will be discarded instead of getting pushed back on the stack.
 */

#include "RPNCalc.h"
#include "DatumStack.h"
#include "Datum.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <cstdio>

using namespace std;

/* default constructor for RPNCalc, initialize the private variable 
 * command_is_int 
 */
RPNCalc::RPNCalc(){
    command_is_int = false;
    
}

/* default destructor for RPNCalc */
RPNCalc::~RPNCalc(){
    
}

/* 
 * run
 *    Purpose: starts the calculator, takes in the commands and directs them
 *             to an execution function
 * Parameters: none
 *     Return: none
 */
void RPNCalc::run(){ 
    string query;
    bool end = false;
    cin >> query;
    while(not cin.fail() and not end){
        execute(query, &end, cin);
        if (not end){
            cin >> query;
        }
    }
    // print out the message at the end of program
    cerr << "Thank you for using CalcYouLater.\n";
}

/* 
 * execute
 *    Purpose: Execute the commands from the input stream
 * Parameters:The command string, a boolean indicating if the program ends, and 
 *             an input stream
 *     Return: none
 */
void RPNCalc::execute(string query, bool* end, istream &input){
    if (query == "quit"){
        *end = true;
    } else if (is_operator(query)){
        if (getStackSize() < 2){
            cerr << "Error: empty_stack\n";
            d.pop();
        } else { 
            operate_math(query);
        }
    } else if (is_compare(query)){
        if (getStackSize() < 2){
            cerr << "Error: empty_stack\n";
            d.pop();
        } else {
            compare(query);
        }
    } else {
        simple_command(query);
        complex_command(query, end, input);
    } 
    // invalid query check
    if (not valid_command(query)) {
        cerr << query << ": unimplemented\n";
    }
}

/* 
 * is_operator 
 *    Purpose: Check if the command is an algebraic operator
 * Parameters: the command string
 *     Return: a boolean indicating if the command is an algebraic operator
 */
bool RPNCalc::is_operator(string query){
    string oper[5] = {"+", "-", "*", "/", "mod"};
    for (int i = 0; i < 5; i++){
        if (query == oper[i]){
            return true;
        }
    }
    return false;
}

/* 
 * is_compare
 *    Purpose: Check if the command is a comparison operator
 * Parameters: the command string
 *     Return: a boolean indicating if the command is a comparison operator
 */
bool RPNCalc::is_compare(string query){
    string compare[5] = {">", "<", "<=", ">=", "=="};
    for (int i = 0; i < 5; i++){
        if (query == compare[i]){
            return true;
        }
    }
    return false;
}

/* 
 * valid_command
 *    Purpose: Check if the input is a valid command
 * Parameters: the command string
 *     Return: a boolean indicating if the command is valid or not
 */
bool RPNCalc::valid_command(string query){
    string valid[13] = {"#t", "#f", "not", "print", "clear", "drop", "dup", 
                        "swap", "{", "exec", "file", "if", "quit"};
    for (int i = 0; i < 13; i++){
        if (query == valid[i]){
            return true;
        }
    }
    if (command_is_int or is_operator(query) or is_compare(query)){
        return true;
    } 
    return false;
}

/* 
 * operate_math
 *    Purpose: Check whether the inputs are of correct type, and call for 
 *             the calculate function to produce the output
 * Parameters: the query string, which is one of the algebraic operators
 *     Return: none
 */
void RPNCalc::operate_math(string query){
    int var[2];
    bool both_are_int = true;
    for (int i = 0; i < 2; i++){
        if (not d.top().isInt()){
            cerr << "Error: datum_not_int\n";
            both_are_int = false;
        } else {
            var[i] = d.top().getInt();
        }
        d.pop();
    }
    if (both_are_int){
        calculate(query, var[0], var[1]);
    }
}

/* 
 * operate_math
 *    Purpose: Calculate a math expression with two integer datums and push
 *             the result to the stack
 * Parameters: the query string, which is one of the algebraic operators, 
 *             the 2 integers to compute
 *     Return: none
 */
void RPNCalc::calculate(string query, int var0, int var1){
    int result = 0;
    bool error = false; // check for division and mod by 0
    if (query == "+"){
        result = var0 + var1;
    } else if (query == "-"){
        result = var1 - var0;
    } else if (query == "*"){
        result = var0 * var1;
    } else if (query == "/"){
        if (var0 == 0){
            cerr << "Error: division by 0.\n";
            error = true;
        } else {
            result = var1 / var0;
        }
    } else if (query == "mod"){
        if (var0 == 0){
            cerr << "Error: division by 0.\n";
            error = true;
        } else {
            result = var1 % var0;
        }
    }
    if (not error){
        d.push(Datum(result));
    }
}

/* 
 * compare
 *    Purpose: Compare the two integer datums and push the result to the stack
 * Parameters: the query string, which is one of the comparison operators
 *     Return: none
 */
void RPNCalc::compare(string query){
    bool result;
    bool both_are_int = true;
    Datum var[2] = {Datum(0), Datum(0)};
    // error check
    for (int i = 0; i < 2; i++){
        if (not d.top().isInt()){
            cerr << "Error: datum_not_int\n";
            both_are_int = false;
        } else {
            var[i] = d.top();
        }
        d.pop();
    }
    if (both_are_int){ // make use of the features of Datum class to compare
        if (query == ">"){
            result = (not (var[1] < var[0])) and (not (var[0] == var[1]));
        } else if (query == "<"){
            result = var[1] < var[0];
        } else if (query == "<="){
            result = (var[1] < var[0]) or (var[0] == var[1]);
        } else if (query == ">="){
            result = not (var[1] < var[0]);
        } else {
            result = var[1] == var[0];
        } 
        d.push(Datum(result));
    }
}

/* 
 * simple_command
 *    Purpose: Execute the simple commands, as well as error check
 * Parameters: the query string
 *     Return: none
 */
void RPNCalc::simple_command(string query){
    command_is_int = false; // keep track of whether current datum is int
    int num = 0;
    if (got_int(query, &num)){
        Datum datum(num);
        d.push(datum);
        command_is_int = true;
    } else if(query == "#t"){
        Datum datum(true);
        d.push(datum);
    } else if (query == "#f"){
        Datum datum(false);
        d.push(datum);
    } else if (query == "not" and not stack_is_empty()){
        inverse();
    } else if (query == "print" and not stack_is_empty()){
        cout << d.top().toString() << endl;
    } else if (query == "clear"){
        d.clear();
    } else if (query == "drop" and not stack_is_empty()){
        d.pop();
    } else if (query == "dup" and not stack_is_empty()){
        d.push(d.top());
    } else if (query == "swap" and not stack_is_empty()){
        swap();
    } 
}

/* 
 * inverse
 *    Purpose: swap the order of the two Datums at the top of the stack
 * Parameters: none
 *     Return: none
 */
void RPNCalc::inverse(){
    if (not d.top().isBool()){
        cerr << "Error: datum_not_bool\n";
        d.pop();
    } else {
        bool this_bool = d.top().getBool();
        d.pop();
        Datum datum(not this_bool);
        d.push(datum);
    }
}

/* 
 * swap
 *    Purpose: swap the order of the two Datums at the top of the stack
 * Parameters: none
 *     Return: none
 * 
 * Note: need at least 2 elements
 */
void RPNCalc::swap(){
    if (getStackSize() < 2){
        cerr << "Error: empty_stack\n";
        d.pop();
    } else {
        Datum temp1 = d.top();
        d.pop();
        Datum temp2 = d.top();
        d.pop();
        d.push(temp1);
        d.push(temp2);
    }
}

/* 
 * stack_is_empty
 *    Purpose: Check if the stack is empty or not
 * Parameters: none
 *     Return: a boolean value indicating if the stack is empty or not
 */
bool RPNCalc::stack_is_empty(){
    if (getStackSize() <= 0){
        cerr << "Error: empty_stack\n";
        return true;
    } else {
        return false;
    }
}

/* 
 * complex_command
 *    Purpose: Execute the complex commands
 * Parameters: the query string, a boolean indicating if the program ends, and 
 *             an input stream
 *     Return: a string of characters from input parsed together 
 */
void RPNCalc::complex_command(string query, bool *end, istream &input){
    if (query == "{"){
        Datum rstring(parseRString(input));
        d.push(rstring);
    } else if (query == "exec"){
        command_exec(end);
    } else if (query == "file"){
        command_file(end);
    } else if (query == "if"){
        command_if(end, input);
    } 
}

/* 
 * parseRString
 *    Purpose: Read in the inputs and parse them into an RString expression
 * Parameters: an object of input stream.
 *     Return: a string of characters from input parsed together 
 */
string RPNCalc::parseRString(istream &input){ 
    string parse = "{ ";
    string temp_string;
    bool closed = false;
    int num_open = 1;
    int num_closed = 0;
    input >> temp_string;
    while (not input.fail() and not closed){
        if (temp_string == "{"){
            num_open++;
        } else if (temp_string == "}"){
            num_closed++;
        } 
        if (num_open == num_closed){  
            closed = true;
            parse = parse + temp_string;
        } else {
            parse = parse + temp_string + " ";
        }
        if (not closed){
            input >> temp_string;
        }
    }
    if (input.fail() and not closed){
        cerr << "Error: reached end of program when searching for }\n";
    }
    if (num_open != num_closed){ // if the braces don't match up
        return "Invalid rstring"; 
    } 
    return parse;
}

/* 
 * command_exec
 *    Purpose: Carry out the "exec" command, which executes the rstring at the 
 *             top of the stack
 * Parameters: a boolean indicating if the program ends
 *     Return: none
 */
void RPNCalc::command_exec(bool *end){
    string open_brace;
    string query;
    if (not d.top().isRString()){
        cerr << "Error: cannot execute non rstring\n";
        d.pop();
    } else {
        stringstream stream(d.top().getRString());
        d.pop();
        stream >> open_brace >> query;
        while (not stream.fail()){
            if (query != "}"){
                execute(query, end, stream);
            }
            stream >> query;
        }
        stream.clear();
    }
}

/* 
 * command_file
 *    Purpose: execute the file command, along with error check 
 * Parameters: a boolean indicating if the program ends
 *     Return: none
 */
void RPNCalc::command_file(bool *end){
    string open_brace;
    string filename, line, query;
    if (not d.top().isRString()){
        cerr << "Error: cannot execute non rstring\n";
        d.pop();
    } else {
        stringstream stream(d.top().getRString());
        d.pop();
        stream >> open_brace >> filename;
        stream.clear();
        ifstream inf(filename);
        if (inf.fail()) {
            cerr << "Unable to read " << filename << endl;
        }
        while (inf >> query){   
            execute(query, end, inf);
        }
        inf.close();    
    }
}

/* 
 * command_if
 *    Purpose: execute the if command, which pops 3 datum and execute either of
 *             the rstring based on the condition.
 * Parameters: a boolean indicating if the program ends, and an input stream
 *     Return: none
 */
void RPNCalc::command_if(bool *end, istream &input){
    Datum falseCase = d.top();
    d.pop();
    if (not falseCase.isRString()){ // pop and check 1st rstring
        cerr << "Error: expected rstring in if branch\n";
        d.pop();
        d.pop();
    } else {
        Datum trueCase = d.top();
        d.pop();
        if (not trueCase.isRString()){ // pop and check 2nd rstring
            cerr << "Error: expected rstring in if branch\n";
            d.pop();
        } else {
            Datum boolean = d.top();
            d.pop();
            if (not boolean.isBool()){ // pop and check the boolean
                cerr << "Error: expected boolean in if test\n";
            } else if (boolean.getBool()){
                d.push(trueCase);
                execute("exec", end, input);
            } else if (not boolean.getBool()){
                d.push(falseCase);
                execute("exec", end, input);
            }
        }
    }
}
 
/*
 * got_int (from the instructors)
 *    Purpose: Return true if the string s can be interpreted as an integer
 *     number, placing the associated integer into the location pointed to by
 *     resultp.
 * Parameter: a string, and a pointer to the int to be modified
 *   Return: a boolean indicating if the string stores an integer
 */
bool RPNCalc::got_int(string s, int *resultp){
        /* Holds the first non-whitespace character after the integer */
        char extra;

        return sscanf(s.c_str(), " %d %c", resultp, &extra) == 1;
}

/* 
 * getStackSize
 *    Purpose: get the current stack size. 
 * Parameters: none
 *     Return: the size of the stack
 */
int RPNCalc::getStackSize(){
    return d.size();
}

/* 
 * getTop
 *    Purpose: get the top Datum of the current stack. For testing
 * Parameters: none
 *     Return: a Datum at the top of the current stack
 */
Datum RPNCalc::getTop(){
    return d.top();
}
