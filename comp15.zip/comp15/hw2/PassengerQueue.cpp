/*
 * PassengerQueue.cpp
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * Implementing all the functions that are used to query and perform actions on 
 * objects of class PassengerQueue. Utilizes the features of vector package for
 * the functions
 *
 * NOTE: Cannot use dequeue and front on empty list, cannot remove passengers
 * at the back or insert passengers due to the characteristics of the data 
 * structure.
 */
 
#include "PassengerQueue.h"
#include "Passenger.h"
#include <iostream>
#include <vector>

using namespace std;

/* 
 * print
 *    Purpose: Print out all the passengers of that passenger queue
 * Parameters: The output stream representing the output file
 *    Returns: none
 */
void PassengerQueue::print(ostream &output) 
{
    for (int i = 0; i < size(); i++)
    {
       queue.at(i).print(output);
    }
}

/* 
 * front
 *    Purpose: Access the first passenger of the queue
 * Parameters: none
 *    Returns: the Passenger at the front of the queue
 *
 * Note: Cannot access the front passenger if the queue is currently empty
 */
Passenger PassengerQueue::front()
{
    if (size() == 0){
        cerr << "ERROR: Passenger queue is empty!" << endl;
        exit(EXIT_FAILURE);
    }
    
    return queue.front();
}

/* 
 * dequeue
 *    Purpose: Remove the first Passenger of the queue
 * Parameters: none
 *    Returns: none
 *
 * Note: Cannot dequeue if the queue is currently empty
 */
void PassengerQueue::dequeue()
{
    if (size() == 0){
        cerr << "ERROR: Passenger queue is empty!" << endl;
        exit(EXIT_FAILURE);
    }
    
    queue.erase(queue.begin());
}

/* 
 * enqueue
 *    Purpose: Add a new passenger to the back of the current queue
 * Parameters: The passenger to be added to the queue
 *    Returns: none
 */
void PassengerQueue::enqueue(const Passenger& passenger)
{
    queue.push_back(passenger);
}

/* 
 * size
 *    Purpose: Give information about the current length of the queue
 * Parameters: none
 *    Returns: none
 */
int PassengerQueue::size()
{
    return queue.size();
}
