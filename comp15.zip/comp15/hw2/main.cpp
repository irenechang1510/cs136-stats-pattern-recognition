/*
 * main.cpp
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * MetroSim is a simulation of the Green Line. It simulates the passenger 
 * queues at each station and a train that goes through all the stations, 
 * letting the passengers embark and disembark the train at the correct station.
 */

#include <iostream>
#include <fstream>
#include <string>

#include "MetroSim.h"
#include "Passenger.h"

using namespace std;


int main(int argc, char *argv[])
{
    // check for correct number of arguments provided
    if (argc < 3 or argc > 4){
        cerr << "Usage: ./MetroSim stationsFile outputFile [commandsFile]";
        cerr << endl;
        exit(EXIT_FAILURE);
    }
    
    MetroSim m1;
    m1.play(argc, argv);

    return 0;
}
