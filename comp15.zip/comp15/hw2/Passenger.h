/*
 * Passenger.h
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * One implementation of the Passenger interface. Stores passenger's id, 
 * passenger's departure and arrival stations. As well as a print function.
 */

#ifndef __PASSENGER_H__
#define __PASSENGER_H__

#include <iostream>

struct Passenger
{

        int id, from, to;
        
        Passenger()
        {
                id   = -1;
                from = -1;
                to   = -1;
        }

        Passenger(int newId, int arrivalStation, int departureStation)
        {
                id   = newId;
                from = arrivalStation;
                to   = departureStation;
        }

        void print(std::ostream &output);

};

#endif

