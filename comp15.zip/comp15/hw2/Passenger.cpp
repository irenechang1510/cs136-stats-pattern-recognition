/*
 * Passenger.cpp
 * 
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * Implement the print function for Passenger class to an output stream
 */

#include <iostream>
#include <string>
#include "Passenger.h"

using namespace std;
/*
 *  print
 *    Purpose: Print information of a passenger to a specified output stream
 * Parameters: An ostream object to store the output
 *    Returns: none
 */
void Passenger::print(ostream &output)
{
      output << "[" << id << ", " << from << "->" << to << "]";

}