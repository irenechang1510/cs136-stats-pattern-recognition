/*
 * PassengerQueue.h
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * One implementation of the PassengerQueue interface. Stores Passenger objects
 * as a queue, preserving their order and performing actions on them. 
 */


#ifndef __PASSENGERQUEUE_H__
#define __PASSENGERQUEUE_H__

#include <iostream>
#include <vector>
#include "Passenger.h"

using namespace std;

class PassengerQueue {
    public:
        void print(ostream &output);
        Passenger front();
        void dequeue();
        void enqueue(const Passenger& passenger);
        int size();
        
    private:
        vector<Passenger> queue;
        
};

#endif
