/*
 * PassengerQueue_tests.cpp
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * Use unit_test framework to test Passenger, PassengerQueue, MetroSim 
 * functions
 */

#include "PassengerQueue.h"
#include "Passenger.h"
#include "MetroSim.h"
#include <cassert>
#include <iostream>
#include <fstream>

using namespace std;

/* 
 * print_passenger_test
 * Use 2 different output streams, cout and an output file to see if passengers 
 * are correctly printed out to the desired stream
 */
void print_passenger_test()
{
    // test to print to the screen
    Passenger p1;
    p1.print(cout);
    Passenger p2(2, 4, 5);
    p2.print(cout);
    
    // test to print to the output file
    ofstream output;
    output.open("test.txt");
    p2.print(output); // cat to see. Successfully printed.
    output.close();
}

/*
 * enqueue_test
 * Create multiple passengers and add them to the queue, checking if the 
 * passengers are correctly added by asserting the size
 *
 * Note: This test also checks function size()
 */
void enqueue_test()
{
    PassengerQueue q1;
    assert(q1.size() == 0);
    Passenger p1;
    q1.enqueue(p1);
    assert(q1.size() == 1);
    Passenger p2(3, 4, 5);
    Passenger p3(2, 6, 7);
    q1.enqueue(p2);
    q1.enqueue(p3);
    assert(q1.size() == 3);
}

/* 
 * print_passengerQueue_test
 * Use 2 different output streams, cout and an output file to see if passenger 
 * queues are correctly printed out to the desired stream
 */
void print_passengerQueue_test()
{
    // test to print to the screen
    PassengerQueue q1;
    q1.print(cout); // should print nothing to the screen.
    Passenger p1(2, 4, 5);
    q1.enqueue(p1);
    q1.print(cout);
    
    // test to print to the output file
    Passenger p2(4, 20, 25);
    ofstream output;
    output.open("test.txt");
    q1.enqueue(p2);
    q1.print(output); // cat to see. Successfully printed.
    output.close();
}

/* 
 * test_front
 * Enqueue and dequeue passengers, and check to see if the front passenger is
 * the correct passenger. Empty queue cannot have front passenger
 */
void test_front()
{
    PassengerQueue q1;
    Passenger p1(1, 2, 4);
    Passenger p2(2, 3, 5);
    q1.enqueue(p1);
    q1.enqueue(p2);
    assert(q1.front().id == 1);
    assert(q1.size() == 2);
    q1.dequeue();
    assert(q1.front().id == 2);
    q1.dequeue();
    
    // should give a warning and exit
    // note: correct message
    //q1.front();
}

/* 
 * test_dequeue
 * Enqueue and dequeue passengers, and check to see if the size decreases as 
 * we dequeue. Empty queue cannot dequeue passenger
 */
void test_dequeue()
{
    PassengerQueue q1;
    Passenger p1(1, 2, 4);
    Passenger p2(2, 3, 5);
    q1.enqueue(p1);
    q1.enqueue(p2);
    Passenger p3 = q1.front();
    assert(p3.id == 1);
    assert(q1.size() == 2);
    q1.dequeue();
    assert(q1.size() == 1);
    q1.dequeue();
    assert(q1.size() == 0);
    
    // should give a warning and exit
    // note: correct message
    // q1.dequeue();
}

/* 
 * test_check_validity
 * Try passing in a non-existent stations file to see if the program exits and 
 * correct message is printed out.
 *
 * Note: Make the function temporarily public for testing, correct messages
 */
// void test_check_validity()
// {
//     MetroSim m; 
//     m.check_validity("station.txt");
//     m.check_validity("command.txt", cout);
// }

/* 
 * init_station
 * Instatiate a metrosim object and call init_station. Assert that the new 
 * station has the correct attributes
 *
 * Note: Make the function temporarily public for testing
 */
void init_station()
{
    MetroSim m;
    Stations s1 = m.init_station("ABC");
    assert(s1.name == "ABC");
    assert(s1.num == 0);
    assert(s1.station_queue.size() == 0);
}

/* 
 * read_station_file_test
 * Instatiate a metrosim object and call read station file, print out the 
 * setting to make sure it correctly reads in the stations
 *
 * Note: Make the function temporarily public for testing.
 *       This test also checks function reset_index_station and print function
 */
void read_station_file_test()
{
    MetroSim m;
    m.read_station_file("stations.txt");
    m.print(); // stations are numbered from 1 to 26
}

/* 
 * metrosim_add_pass_test
 * Instatiate a metrosim object, call add passenger function and print the 
 * result to see if the passengers are put in their correct departure stations
 *
 * Note: Make the function temporarily public for testing.
 */
void metrosim_add_pass_test()
{
    MetroSim m;
    m.read_station_file("stations.txt");
    m.add_passenger("p 1 2");
    m.add_passenger("p 3 4");
    m.add_passenger("p 1 5");
    m.add_passenger("p 6 26");
    m.add_passenger("p 26 1");
    m.print();
}

/* 
 * move_station_test
 * Instatiate a metrosim object, call move station multiple times to make sure
 * there is no errors.
 *
 * Note: Make the function temporarily public for testing.
 */
void move_station_test()
{
    MetroSim m;
    m.read_station_file("stations.txt");
    // temporarily initialize the train to stay at station 25, then use 2
    // consecutive move function to make sure the train come back to the 
    // beginning of the station list
    m.move_station(cout); 
    m.move_station(cout);
    
    // commands2.txt includes > 400 move queries to see if the train 
    // successfully loops back multiple times, check with diff
    m.read_command("commands2.txt", cout);
    
} 

/* 
 * board_leave_train_test
 * Instatiate a metrosim object, create passengers and call move station 
 * multiple times to make sure passengers correctly board and leave the train
 *
 * Note: Make the function temporarily public for testing.
 */
 void board_leave_train_test()
 {
     // also created a command file with the same commands to diff against 
     // the demo program.
     MetroSim m;
     m.read_station_file("stations.txt");
     m.add_passenger("p 1 2");
     m.add_passenger("p 3 4");
     m.print();
     m.move_station(cout);
     m.move_station(cout);
     m.move_station(cout);
     m.add_passenger("p 4 6");
     m.move_station(cout);
     m.move_station(cout);
 }
 
/* 
 * query_test
 * Instatiate a metrosim object, call different queries and test that they
 * produce the desired effects
 *
 * Note: Make the function temporarily public for testing.
 */
void query_test()
{
    MetroSim m1;
    m1.read_station_file("stations.txt");
    m1.query("m f", cout); // should print out the message
    m1.query("m m", cout);
    m1.query("p 1 2", cout);

}

/* 
 * read_command_file_test
 * Instatiate a metrosim object and call read command, the program should 
 * automatically run the queries and perform proper actions
 *
 * Note: Make the function temporarily public for testing.
 */
void read_command_file_test()
{
    MetroSim m;
    m.read_station_file("stations.txt");
    // if argument is cout, should print to screen
    m.read_command("test_commands.txt", cout);
    m.read_command("commands2.txt", cout);
    // if argument is output file, should print to output file
    ofstream output;
    output.open("test.txt");
    m.read_command("test_commands.txt", output);
    output.close();
}

/* 
 * general test
 * test the program on different command files to see if there is any valgrind
 * errors.
 */
 void general_test()
 {
     MetroSim m;
     // stations file with 52 stations
     m.read_station_file("stations.txt");
     // original command file
     m.read_command("test_commands.txt", cout);
     // command file with no m f at the end
     m.read_command("commands3.txt", cout);
     // command file with all m m queries
     m.read_command("commands2.txt", cout);
     
 }