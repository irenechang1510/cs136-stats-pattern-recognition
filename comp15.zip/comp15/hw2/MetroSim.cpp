/*
 * MetroSim.cpp
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * Put together the simulation program, It reads in necessary files, builds 
 * stations and train, performs query from query or from command file and 
 * prints output to the screen or output files.
 *
 * NOTE: Filenames and queries have to be valid
 */

#include "MetroSim.h"
#include "PassengerQueue.h"
#include "Passenger.h"
#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

/* 
 * play
 *    Purpose: Set up the simulation using the files provided and run the 
 *             simulation either by prompting user input or reading in commands 
 *             from a command file
 * Parameters: the number of arguments provided to the program, and reference 
 *             to the array storing those arguments
 *    Returns: none
 */
void MetroSim::play(int argc, char *argv[])
{
    // for printing to a file
    ofstream output;
    output.open(argv[2]);
    check_validity(argv[1]);
    check_validity(argv[3]);
    
    read_station_file(argv[1]);
    end = false;  
    
    while (not end){
        print(); // print initial state
        if (argc == 3){
            cout << "Command? ";
            string command;
            getline(cin, command);
            query(command, output);        
        } else {
            read_command(argv[3], output);
        }
    }
    output.close();
}

/*
 * check_validity
 *    Purpose: Check the validity of the files given, quit the program 
 *             immediately if any of the station/command file is nonexistent
 * Parameters: The name of the file we want to check
 *    Returns: none
 */
void MetroSim::check_validity(string filename){
    ifstream inf(filename);
    if (inf.fail()) {
        cerr << endl;
        cerr << "Error: could not open file " << filename << endl;
        exit(EXIT_FAILURE);
    }
    inf.close();
}

/* 
 * read_station_file
 *    Purpose: Set up the stations for the simulation from the file provided by
               the user, resize the train to be equal to number of stations
 * Parameters: The name of the file containing all the stations
 *    Returns: none
 */
void MetroSim::read_station_file(string filename)
{
    ifstream inf(filename);
    
    string station;
    int num_station = 0;
    getline(inf, station);
    while(not inf.eof()){
        // create new station and add to the list of stations
        Stations new_station = init_station(station);
        stations.push_back(new_station);
        num_station++;
        getline(inf, station);
    }
    inf.close();
    // resize the train
    train.train_pass.resize(num_station);
    // change 0-based indexing to 1-based indexing
    reset_index_station();
}

/* 
 * init_station
 *    Purpose: Initialize the information for all stations, as well as initiate
 *             the train and other relevant variables
 * Parameters: A line in the station input file that contains information for 
               one station
 *    Returns: an Station object
 */
Stations MetroSim::init_station(string name)
{
    Stations new_station;
    new_station.name = name;
    new_station.num = 0;
    
    train.at_station = 1;
    num_pass = 0; // to be used for passenger's id
    
    return new_station;
} 

/* 
 * reset_index_station
 *    Purpose: Change 0-based indexing of the stations to 1-based indexing
 * Parameters: none
 *    Returns: none
 */
void MetroSim::reset_index_station()
{
    for (int i = 0; i < (int) stations.size(); i++){
        stations.at(i).num = i + 1;
    }
}

/* 
 * print
 *    Purpose: Print out the simulation with all the stations and passengers
 *             after any query is made
 * Parameters: none
 *    Returns: none
 */
void MetroSim::print()
{
    cout << "Passengers on the train: {";
    for (int i = 0; i < (int) train.train_pass.size(); i++){
        train.train_pass.at(i).print(cout);
    }
    cout << "}" << endl;
    for (int i = 0; i < (int) stations.size(); i++)
    {
      if (train.at_station == i + 1){
          cout << "TRAIN: ";
      } else {
          cout << "       ";
      }
      cout << "[" << stations.at(i).num << "] "; 
      cout << stations.at(i).name;
      cout << " {";
      stations.at(i).station_queue.print(cout); // add pass here
      cout << "}" << endl;
    }
}

/* 
 * read_command
 *    Purpose: if provided, read in the commands from the command file and 
               execute them one by one
 * Parameters: a filename for the command file and an output stream 
               representing the output file we should print to
 *    Returns: none
 */
void MetroSim::read_command(string filename, ostream &output)
{
    string command;
    
    ifstream inf(filename);
    
    getline(inf, command);
    while(not inf.eof()){
        cout << "Command? ";
        query(command, output);
        getline(inf, command);
    }
    if (not end){
        cout << "Command? ";
        query("m f", output);
    }
    inf.close();
}

/* 
 * query
 *    Purpose: Execute the query provided
 * Parameters: a filename for the command file and an output stream 
               representing the output file we should print to
 *    Returns: none
 */
void MetroSim::query(string command, ostream &output)
{
    if (command == "m f"){
        cout << "Thanks for playing MetroSim. Have a nice day!" << endl;
        end = true;
    } else if (command == "m m"){
        // move to next station
        move_station(output);
    } else if (command[0] == 'p'){
        // add passenger at some station
        add_passenger(command);
        print();
    }
}

/* 
 * add_passenger
 *    Purpose: create a new passenger and add them to the appropriate departure 
 *             stations queue
 * Parameters: The add passenger command string that contains the new 
 *             passenger's information
 *    Returns: none
 */
void MetroSim::add_passenger(string command) 
{
    stringstream sstr;
    sstr.str(command);
    string skip;
    int from_station, to_station;
    sstr >> skip >> from_station >> to_station;
    
    num_pass++;
    Passenger p = Passenger(num_pass, from_station, to_station);
    stations.at(from_station - 1).station_queue.enqueue(p);
    
    sstr.clear();
}

/* 
 * move_station
 *    Purpose: move the train to the next station
 * Parameters: The output stream containing the output file
 *    Returns: none
 */
void MetroSim::move_station(ostream &output)
{
    board_train();
    if (train.at_station == (int) stations.size()){
        train.at_station = 1;
    } else {
        train.at_station++;
    }
    leave_train(output);
    print();
}

/* 
 * board_train
 *    Purpose: Let all the passengers at the current station that the train
 *             is at board the train in the correct order
 * Parameters: none
 *    Returns: none
 */
void MetroSim::board_train()
{
    int curr_station = train.at_station; 
    while (stations.at(curr_station - 1).station_queue.size() > 0){
        Passenger p = stations.at(curr_station - 1).station_queue.front();
        
        // be put on the train based on destination station
        train.train_pass.at(p.to - 1).enqueue(p);
        stations.at(curr_station - 1).station_queue.dequeue();
    }
    
}

/* 
 * leave train
 *    Purpose: Let all the passengers who have the destination station being
 *             the current station that the train is at leave the train, and
 *             print information of those passengers to the output file.
 * Parameters: The output stream containing the output file
 *    Returns: none
 */
void MetroSim::leave_train(ostream &output)
{
    int curr_station = train.at_station; 
    // find queue whose destination station is this station.
    while (train.train_pass.at(curr_station - 1).size() > 0){
        output << "Passenger ";
        output << train.train_pass.at(curr_station - 1).front().id;
        output << " left train at station ";
        output << stations.at(curr_station - 1).name << endl;
        train.train_pass.at(curr_station - 1).dequeue();
    }
}
