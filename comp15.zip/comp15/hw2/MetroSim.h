/*
 * MetroSim.h
 *
 * COMP 15 homework 2
 * by Irene Chang, February 2021
 * 
 * One implementation of the MetroSim interface. This class builds train and 
 * stations for the simulation. Utilize the PassengerQueue class, and comes
 * with the queries that are used to interact with the simulation. 
 * Helper functions read necessary information from files and construct a 
 * simulation.
 */

#ifndef _METROSIM_H_
#define _METROSIM_H_

#include "PassengerQueue.h"

// Put any other necessary includes here
#include "Passenger.h"
#include <vector>

// Put any other structs you need here
struct Stations{
    string name;
    int num;
    PassengerQueue station_queue;
};

struct Train{
    int at_station;
    vector<PassengerQueue> train_pass;
};

class MetroSim
{
public:
    void play(int argc, char *argv[]);
    
private:
    vector<Stations> stations;
    string commandFile;
    Train train;
    int num_pass;
    bool end; 
    
    // error check function
    void check_validity(string filename);
    
    // initialize stations functions
    void read_station_file(string filename);
    Stations init_station(string station_name);
    void reset_index_station();
    void print();
    
    // query functions
    void query(string command, ostream &output);
    void read_command(string filename, ostream &output);
    
    // train's functions
    void move_station(ostream &output);
    void leave_train(ostream &output);
    void board_train();
    
    // passenger's function
    void add_passenger(string command);
};

#endif
