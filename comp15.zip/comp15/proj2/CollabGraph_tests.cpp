/*
 * CollabGraph_tests.cpp
 *
 * COMP 15 project 2
 * by Irene Chang, April 2021
 * 
 * Use unit_test framework to test some functions in CollabGraph and SixDegrees
 * Private functions are made temporarily public for testing.
 
 * Note: The majority of the tests are done through running the program in the
 * terminal and documented in README. Some functions are later modified for
 * the purpose of modularity so they are commented out in the test
 */


#include "Artist.h"
#include "CollabGraph.h"
#include "SixDegrees.h"
#include <cassert>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <stack>

using namespace std;

/* 
 * Test the functions that read in and populate the graph with artists' 
 * information
 */
void populate_artists()
{
    SixDegrees s;
    s.read_artist_file("artists.txt");
    CollabGraph c = s.get_collab();
    Artist bts("BTS"), blackpink("BLACKPINK"), taylor("Taylor Swift"),
    ed("Ed Sheeran"), fifty("50Cent");
    //c.print_graph(cout);
    assert(c.is_vertex(bts) == true);
    assert(c.is_vertex(blackpink) == true);
    assert(c.is_vertex(taylor) == true);
    assert(c.get_edge(taylor, ed) == "End Game");
    assert(c.is_vertex(fifty) == true);
    
}

/* 
 * Test if the edges are populated correctly by using the get_vertex_neighbor
 * function, print out the vector of neighbors and visually check if it 
 * matches the information in the data file.
 */
void get_vertex_neighbor_test()
{
    SixDegrees s;
    s.read_artist_file("artists.txt");
    CollabGraph c = s.get_collab();
    Artist taylor("Taylor Swift"), bts("BTS"), lauv("Lauv");
    vector<Artist> tay_neighbor = c.get_vertex_neighbors(taylor);
    vector<Artist> bts_neighbor = c.get_vertex_neighbors(bts);
    vector<Artist> lauv_neighbor = c.get_vertex_neighbors(lauv);
    cerr << "Taylor's neighbors are: " << endl;
    for (int i = 0; i < tay_neighbor.size(); i++){
        cerr << tay_neighbor.at(i) << endl;
    }
    cerr << "Lauv's neighbors are: " << endl;
    for (int i = 0; i < lauv_neighbor.size(); i++){
        cerr << lauv_neighbor.at(i) << endl;
    }
    cerr << "BTS's neighbors are: " << endl;
    for (int i = 0; i < bts_neighbor.size(); i++){
        cerr << bts_neighbor.at(i) << endl;
    }    
}

/* 
 * Test different (valid/invalid) query to see if it correctly enters the 
 * corresponding block of command
 */
void valid_query_test()
{
    SixDegrees s;
    s.read_artist_file("artists.txt");
    CollabGraph c = s.get_collab();
    // s.query("bfs", cout, cin);
    // s.query("bfs dfs", cout, cin);
    // s.query("dfs", cout, cin);
    // s.query("dfs kjfhakj", cout, cin);
    // s.query("not", cout, cin);
    // s.query("kdahk", cout, cin);
    s.query(" ", cout, cin); // space as invalid command
}

/* 
 * Check the breadth_first function, which will also be the framework for dfs
 * and not function. The size and the artists pushed into the stack should be
 * accurate 
 *
 * Note: the tests here are done before the functions are modified to improve 
 * the modularity of the program.
 * Before it was modified, bfs function returns a stack<Artist>, so I print out
 * all the artists in the stack and visually check it.
 * The edge cases such as invalid artists are checked via the terminal.
 */
void breadth_first_valid_test()
{
    SixDegrees s;
    s.read_artist_file("artists.txt");
    CollabGraph c = s.get_collab();
    Artist nicki("Nicki Minaj"), bts("BTS"), avril("Avril Lavigne");
    // test the helper breadth_first first
    // stack<Artist> result = s.breadth_first(nicki, bts, cout);
    // cerr << (int) result.size() << endl;
    // while (not result.empty()){
    //     cerr << result.top().get_name() << endl;
    //     result.pop();
    // }
    
    // result = s.breadth_first(avril, bts, cout);
    // cerr << (int) result.size() << endl; // should be 0
    
    /****************************************************/
    // test the main breadth_first
    // s.breadth_first(cout);
    // tests include: The Pussycat Dolls - Red Velvet, Aretha Franklin - BTS
    // Sia - Sia (invalid), Shakira - Yhhewhakh (non-existent artist)
}