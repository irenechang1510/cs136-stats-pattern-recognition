/*
 * main.cpp
 *
 * COMP 15 Project 2: Six Degrees of Collaboration
 * 
 * by Irene Chang, April 2021.
 * 
 * SixDegrees is a graph representation of artists and their collaboration
 * network. main.cpp is used to kick off this simulation and let users interact
 * with the program by querying the connection between different artists. It
 * also checks if the user's command to run the program is valid ro not.
 */

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

#include "CollabGraph.h"
#include "SixDegrees.h"
#include "Artist.h"

int main(int argc, char *argv[])
{
    // check for correct number of arguments provided
    if (argc < 2 or argc > 4){
        cerr << "Usage: ./SixDegrees dataFile [commandFile] [outputFile]";
        cerr << endl;
        exit(EXIT_FAILURE);
    }
    
    SixDegrees s1;
    s1.run(argc, argv);
    
    return 0;
}
