/*
 * SixDegrees.cpp
 *
 * COMP 15 project 2
 * by Irene Chang, April 2021
 * 
 * Implementation of the SixDegrees class. SixDegrees creates a graph with
 * information of the artists in the provided data file. After that, users can 
 * interact with the graph by putting in queries, or passing in a file of 
 * commands.
 */
 
#include "SixDegrees.h"
#include "CollabGraph.h"
#include "Artist.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

// run
// Purpose: starts the simulation, set up the graph and take in queries
// Parameter: number of argument on the command line and array of the arguments
// Return : none
void SixDegrees::run(int argc, char *argv[])
{
    if (argc == 3 or argc == 4){ 
        check_validity(argv[2]); 
    }
    
    read_artist_file(argv[1]);
    end = false;
    
    while (not end){
        if (argc == 2){ 
            string command;
            getline(cin, command);
            query(command, cout, cin);
        } else if (argc == 3){ // if commandFile provided
            read_command(argv[2], cout);
        } else if (argc == 4){ // if output file provided
            ofstream output;
            output.open(argv[3]);
            read_command(argv[2], output);
            output.close();
        }
    }
}

// check_validity
// Purpose: check the validity of the files provided
// Parameter: filename to be checked
// Return: none
void SixDegrees::check_validity(string filename)
{
    ifstream inf(filename);
    if (inf.fail()) {
        cerr << filename << " cannot be opened." << endl;
        exit(EXIT_FAILURE);
    }
    inf.close();
}

// read_artist_file
// Purpose: get the information of all artists and set up the graph
// Parameter: the filename of all artists' data
// Return: none
void SixDegrees::read_artist_file(string filename)
{
    check_validity(filename);
    ifstream inf(filename);
    string temp;
    bool is_artist = true;
    Artist artist;
    while(getline(inf, temp)){
    // if hit "*" (end of an artist), then create artist and insert into graph
        if (temp == "*"){
            collab.insert_vertex(artist);
            artist_list.push_back(artist);
            getline(inf, temp);
            is_artist = true;
        } 
        // after insertion, flag that the next item is new artist's name
        if (is_artist){
            Artist new_artist(temp);
            artist = new_artist;
            is_artist = false;
        } else { // if not new artist, then it's the curr artist's songs
            artist.add_song(temp);
        }
    }
    inf.close();
    // insert edges
    populate_edges();
}

// populate_edges
// Purpose: create the edges based on the collaboration between artists
// Parameter: none
// Return: none
void SixDegrees::populate_edges()
{
    Artist artist1, artist2;
    for (int i = 0; i < (int) artist_list.size(); i++){
        artist1 = artist_list.at(i);
        for (int j = 0; j < (int) artist_list.size(); j++){
            if (i != j){ // avoid self-connection
                artist2 = artist_list.at(j);
                string song = artist1.get_collaboration(artist2);
                if (song != ""){ // if there exists collab between these two
                    collab.insert_edge(artist1, artist2, song);
                }
            }
        }
    }
}

// read_command
// Purpose: if command file is provided, then read in and execute the commands
// Parameter: the filename and an output stream
// Return: none
void SixDegrees::read_command(string filename, ostream &output)
{
    string command;
    
    ifstream inf(filename);
    
    while(getline(inf, command)){
        query(command, output, inf);
    }
    // if reaches the end of file but no "quit" command
    if (not end){
        query("quit", output, inf);
    }
    inf.close();
}

// query
// Purpose: execute the command from the input stream
// Parameter: the command, the output and input stream
// Return: none
//
// Note: the artists input has to be on different lines from the command 
// and each artist also needs to be provided on different lines in order for 
// the query to be valid. 
void SixDegrees::query(string command, ostream &output, istream &input)
{ 
    if (command == "bfs" or command == "dfs" or command == "not"){
        execute(command, output, input);
    } else if (command == "quit" or input.eof()){
        end = true;
    } else {
        output << command << " is not a command. Please try again." << endl;
    }
}

// execute
// Purpose: helper for query. Set up the source and destination artists and 
//          make the call to the appropriate function
// Parameter: the command string, the input and output streams
// Return: none
void SixDegrees::execute(string command, ostream &output, istream &input)
{
    collab.clear_metadata();
    // create 2 Artist object to check validity for source and desr
    Artist artist1, artist2;
    string name1, name2;
    getline(input, name1);
    getline(input, name2);
    bool first_valid = true, second_valid = true;
    artist1.set_name(name1);
    artist2.set_name(name2);
    
    first_valid = check_artist_valid(artist1, output);
    second_valid = check_artist_valid(artist2, output);
    bool valid = (first_valid and second_valid);
    
    if (valid){
        if (command == "bfs"){
            breadth_first(artist1, artist2, output);
        } else if (command == "dfs"){
            depth_first(artist1, artist2, output);
        }
    } 
    // separate line because we still want to check the validity of all artists 
    // involved in "not" up to "*"
    if (command == "not") {  
        exclusive(output, input, artist1, artist2, valid);
    }
}

// check_artist_valid
// Purpose: check if the given artist is in the graph or not
// Parameter: the artist to be checked and the output stream
// Return : boolean indicating whether the artist is in the graph or not
bool SixDegrees::check_artist_valid(Artist &artist, ostream &output)
{
    if (not collab.is_vertex(artist)){
        output << "\"" << artist.get_name() << "\""
               << " was not found in the dataset :("
               << endl;
        return false;
    }
    return true;
}

// breadth_first
// Purpose: traverse the graph using bfs to find shortest path between the
//          source and destination artists
// Parameter: the source, dest artists and the output stream
// Return: none
//
// Note: Cannot do bfs from an artist to itself
void SixDegrees::breadth_first(Artist &source, Artist &dest, ostream &output)
{
    stack<Artist> result;
    queue<Artist> q;
    if (not collab.is_marked(source) and not collab.is_marked(dest)){
        q.push(source);
    } 
    while (not q.empty()){
        Artist a = q.front();
        q.pop();
        collab.mark_vertex(a);
        vector<Artist> neighbors = collab.get_vertex_neighbors(a);
        for (int i = 0; i < (int) neighbors.size(); i++){
            // case when neighbor is not visited yet and it's not the dest
            if (not collab.is_marked(neighbors.at(i))){
                collab.set_predecessor(neighbors.at(i), a);
                q.push(neighbors.at(i));
                if (neighbors.at(i) == dest){ // when found the connection
                    result = collab.report_path(source, dest);
                }
            }
        }
    }
    print_path(result, output, source, dest);
}

// depth_first
// Purpose: traverse the graph using dfs to find any path between the
//          source and destination artists
// Parameter: the source, dest artists and the output stream
// Return: none
//
// Note: Cannot do bfs from an artist to itself
void SixDegrees::depth_first(Artist &source, Artist &dest, ostream &output)
{
    stack<Artist> result;
    stack<Artist> s;
    
    s.push(source);
    while (not s.empty()){
        Artist a = s.top();
        s.pop();
        collab.mark_vertex(a);
        vector<Artist> neighbors = collab.get_vertex_neighbors(a);
        for (int i = 0; i < (int) neighbors.size(); i++){
            // case when neighbor is not visited yet and it's not the dest
            if (not collab.is_marked(neighbors.at(i))){
                collab.set_predecessor(neighbors.at(i), a);
                s.push(neighbors.at(i));
                if (neighbors.at(i) == dest){ // when found the connection
                    result = collab.report_path(source, dest);
                }
            }
        }
    }
    print_path(result, output, source, dest);   
}

// exclusive
// Purpose: traverse the graph using bfs to find shortest path between the
//          source and destination artists excluding the artists specified
// Parameter: the source, dest artists and the output and input stream
// Return: none
//
// Note: Cannot do bfs from an artist to itself
void SixDegrees::exclusive(ostream &output, istream &input, Artist &source, 
    Artist &dest, bool first_two_valid)
{
    vector<Artist> artists;
    string name;
    bool fail = false;
    getline(input, name);
    while (name != "*" and !input.eof()){
        Artist artist(name);
        artists.push_back(artist);
        getline(input, name);
    }
    // loop through and mark each involving artist as visited
    for (int i = 0; i < (int) artists.size(); i++){
        if(check_artist_valid(artists.at(i), output)){
            collab.mark_vertex(artists.at(i));
        } else {
            fail = true;
        }
    }
    if(not fail and first_two_valid){
        breadth_first(source, dest, output);
    }
}

// print_path
// Purpose: print path from one artist to another from the constructed stack
// Parameter: the stack representing the path, output stream, source and dest
//            artists
// Return: none
void SixDegrees::print_path(stack<Artist> result, ostream &output, 
    Artist &source, Artist &dest)
{
    if (result.empty()){
        output << "A path does not exist between \"" << source.get_name()
               << "\" and \"" << dest.get_name() << "\"." 
               << endl;
    } else {
        Artist from = result.top();
        result.pop();
        while (not result.empty()){
            Artist to = result.top();
            output << "\"" << from.get_name() << "\" collaborated with \"" 
                   << to.get_name() << "\" in \"" << collab.get_edge(from, to) 
                   << "\"." << endl;
            from = to;
            result.pop();
        }
        output << "***" << endl;
    }
}

/*********************** for testing *************************************/
// CollabGraph SixDegrees::get_collab()
// {
//     return collab;
// }

