/*
 * SixDegrees.cpp
 *
 * COMP 15 project 2
 * by Irene Chang, April 2021
 * 
 * The interface of SixDegrees class. The purpose of this class is to set up 
 * the information for the artist network and execute the commands that users 
 * put in to query the data between these artists.
 */

#ifndef _SIXDEGREES_H_
#define _SIXDEGREES_H_

#include "CollabGraph.h"
#include "Artist.h"
#include <vector>

using namespace std;

class SixDegrees
{
public:
    void run(int argc, char *argv[]);
    
private:
    CollabGraph collab;
    vector<Artist> artist_list;
    bool end; 
    
    
    // error check function
    void check_validity(string filename);
    bool check_artist_valid(Artist &artist, ostream &output);
    
    // initialize artists functions
    void read_artist_file(string filename);
    void populate_edges();
    
    // query functions
    void query(string command, ostream &output, istream &input);
    void read_command(string filename, ostream &output);
    void execute(string command, ostream &output, istream &input);
    
    // traversal functions 
    void breadth_first(Artist &artist1, Artist &artist2, ostream &output);
    void print_path(stack<Artist> result, ostream &output, Artist &source, 
        Artist &dest);
    void depth_first(Artist &artist1, Artist &artist2, ostream &output);
    void exclusive(ostream &output, istream &input, Artist &artist1, 
        Artist &artist2, bool first_two_valid);
        
    /************************** For testing ******************************/
    //CollabGraph get_collab();
};

#endif
