/*
 * BinarySearchTree.cpp
 * COMP15
 * Spring 2021
 *
 * Implementation of the Binary Search Tree class.
 * Behaves like a standard BST except that it handles multiplicity
 * If you insert a number twice  and then remove it once, then it will
 * still be in the data structure
 */

#include <cstring>
#include <iostream>
#include <limits>

#include "BinarySearchTree.h"

using namespace std;

// default constructor
// create an empty binary search tree 
BinarySearchTree::BinarySearchTree()
{
        root = nullptr;
}

// destructor
// delete the current bst using post order method
BinarySearchTree::~BinarySearchTree()
{
        // walk tree in post-order traversal and delete
        post_order_delete(root);
        root = nullptr;  // not really necessary, since the tree is going
                         // away, but might want to guard against someone
                         // using a pointer after deleting
}

// post_order_delete
//    Purpose: helper function for the destructor to burn the tree
// Parameters: pointer to a node to start the deletion
//     Return: None
void BinarySearchTree::post_order_delete(Node *node)
{
        if (node == nullptr){
                return;
        } 
                
        post_order_delete(node->left);
        post_order_delete(node->right);
        
        delete node;
}

// copy constructor
//    Purpose: initialize a bst by deep copy from another tree
// Parameters: address of the source tree to copy
BinarySearchTree::BinarySearchTree(const BinarySearchTree &source)
{
        // use pre-order traversal to copy the tree
        root = pre_order_copy(source.root);
}

// assignment overload
//    Purpose: makes the current tree contain the same
//          information as the one on the right hand side
// Parameters: address of the source tree to assign to the current tree
BinarySearchTree &BinarySearchTree::operator=(const BinarySearchTree &source)
{
        // check for self-assignment
        if (root != source.root){ 
            // delete current tree if it exists
            if (root != nullptr){
                    post_order_delete(root);
            }
            // use pre-order traversal to copy the tree
            this->root = pre_order_copy(source.root);
        }
        return *this;
}

// pre order copy
//    Purpose: helper function for the copy constructo and assignment operator,
//             assign the values of this node to another
// Parameters: pointer to a node to start the copying
//     Return: The copy node
BinarySearchTree::Node *BinarySearchTree::pre_order_copy(Node *node) const
{
        if (node == nullptr){
            return nullptr;
        } 
        Node *copy = new Node;
        copy->data = node->data;
        copy->count = node->count;
        copy->left = pre_order_copy(node->left);
        copy->right = pre_order_copy(node->right);
        return copy;
}

// find min
//    Purpose: find the minimum value in the tree
// Parameters: none
//     Return: minimum value of the tree
int BinarySearchTree::find_min() const
{
        if (root == nullptr)
                return numeric_limits<int>::max(); // INT_MAX

        return find_min(root)->data;
}

// find min
//    Purpose: find the node storing the minimum value in the tree
// Parameters: a node in the tree to start the find
//     Return: pointer to the node storing minimum value of the tree
BinarySearchTree::Node *BinarySearchTree::find_min(Node *node) const
{
        if (node->left == nullptr){
            return node;
        } 
        
        return find_min(node->left);
}

// find max
//    Purpose: find the maximum value in the tree
// Parameters: none
//     Return: maximum value of the tree
int BinarySearchTree::find_max() const
{
        if (root == nullptr)
                return numeric_limits<int>::min(); // INT_MIN

        return find_max(root)->data;
}

// find max
//    Purpose: find the node storing the maximum value in the tree
// Parameters: a node in the tree to start the find
//     Return: pointer to the node storing maximum value of the tree
BinarySearchTree::Node *BinarySearchTree::find_max(Node *node) const
{
        if (node->right == nullptr){
            return node;
        } 
        
        return find_max(node->right);
}

// contains
//    Purpose: find if the tree contains a particular value
// Parameters: a value we want to examine
//     Return: a boolean indicating if the value is in the tree or not
bool BinarySearchTree::contains(int value) const
{
        if (root == nullptr){
            return false;
        }
        return contains(root, value);
        
}

// contains
//    Purpose: find if the tree contains a particular value
// Parameters: pointer to a node and a value to find
//     Return: a boolean indicating if the value is in the tree or not
bool BinarySearchTree::contains(Node *node, int value) const
{
        if (node == nullptr){
            return false;
        } else if (value == node->data){
            return true;
        } else if (value < node->data){
            return contains(node->left, value);
        } else {
            return contains(node->right, value);
        }
}
 
// insert
//    Purpose: insert a value to a tree
// Parameters: a value we want to insert
//     Return: none
void BinarySearchTree::insert(int value)
{
        insert(root, nullptr, value);
}

// insert
//    Purpose: insert a value to a tree
// Parameters: a pointer to a node, pointer to its parent, and value to insert
//     Return: none
void BinarySearchTree::insert(Node *node, Node *parent, int value)
{
        // base case, a node should be created here
        if (node == nullptr){
            node = new Node;
            node->data = value;
            node->count = 1;
            node->left = nullptr;
            node->right = nullptr;
            if (root == nullptr){
                root = node;
            }
            else {
                if(value < parent->data){
                    parent->left = node;
                } else {
                    parent->right = node;
                }
            }
        } else { // recursive case
            if (value < node->data){
                insert(node->left, node, value);
            } else if (value > node->data){
                insert(node->right, node, value);
            } else {
                node->count++;
            }
        }
}

// remove
//    Purpose: remove a value to a tree
// Parameters: a value we want to remove
//     Return: a boolean indicating if the value is able to remove or not
bool BinarySearchTree::remove(int value)
{
        return remove(root, nullptr, value);
}

// remove
//    Purpose: remove a value to a tree, implement the public function
// Parameters: a pointer to a node, pointer to its parent, and value to remove
//     Return: a boolean indicating if the value is able to remove or not
bool BinarySearchTree::remove(Node *node, Node *parent, int value)
{
        if (node == nullptr){
            return false;
        }
        if (node->data == value){
            return remove_node(node, parent);
        } else if (node->data < value){
            return remove(node->right, node, value);
        } else {
            return remove(node->left, node, value);
        }
}

// remove_node
//    Purpose: remove a value to a tree, helper to the remove function
// Parameters: a pointer to a node, pointer to its parent
//     Return: a boolean indicating if the value is able to remove or not
bool BinarySearchTree::remove_node(Node *node, Node *parent)
{
        // if count > 1
        if (node->count >= 2){
            node->count--;
            return true;
        } // if no child
        else if (node->left == nullptr and node->right == nullptr){
            zero_child_remove(node, parent);
            return true;
        } // 2 children
        else if (node->left != nullptr and node->right != nullptr) {
            Node *smallest = find_min(node->right);
            Node *smallest_parent = find_parent(node, smallest);
            node->data = smallest->data;
            node->count = smallest->count;
            return remove_n_times(smallest, smallest_parent, smallest->data, 
                smallest->count);
        } // if 1 child
        else if (node->left != nullptr or node->right != nullptr){
            one_child_remove(node);
            return true;
        } 
        return false;
}

// remove_n_times
//    Purpose: remove a value for a number of time based on its count
// Parameters: a pointer to a node, pointer to its parent, value to remove, how
//             many times to remove
//     Return: a boolean indicating if the value is able to remove or not
bool BinarySearchTree::remove_n_times(Node *node, Node *parent, int value, 
    int times){
        if (times == 1){
            return remove(node, parent, value);
        } 
        return remove(node, parent, value) and 
        remove_n_times(node, parent, value, times - 1);
}

// zero_child_remove
//    Purpose: remove a node with no child
// Parameters: a pointer to a node, pointer to its parent
//     Return: none
void BinarySearchTree::zero_child_remove(Node *node, Node *parent){
        if (parent == nullptr){
            delete node;
            root = nullptr;
        }
        else if (node->data < parent->data){
            delete parent->left;
            parent->left = nullptr;
        } else {
            delete parent->right;
            parent->right = nullptr;
        }
}

// one_child_remove
//    Purpose: remove a node with 1 child
// Parameters: a pointer to a node, pointer to its parent
//     Return: none
void BinarySearchTree::one_child_remove(Node *node)
{
        Node *child_node = node;
        // when only child is right subtree, substitute with min value
        if (node->right != nullptr){
            child_node = node->right;
            Node *smallest = find_min(child_node);
            Node *temp = new Node;
            temp->data = smallest->data;
            temp->count = smallest->count;
            Node *smallest_parent = find_parent(node, smallest);
            remove_n_times(smallest, smallest_parent, smallest->data, 
                smallest->count);
            node->data = temp->data;
            node->count = temp->count;
            delete temp;
        } // when only child is left subtree, substitute with max value
        else if (node->left != nullptr){    
            child_node = node->left;
            Node *largest = find_max(child_node);
            Node *temp = new Node;
            temp->data = largest->data;
            temp->count = largest->count;
            Node *largest_parent = find_parent(node, largest);
            remove_n_times(largest, largest_parent, largest->data, 
                largest->count);
            node->data = temp->data;
            node->count = temp->count;
            delete temp;
        }    
}

// tree_height
// Purpose: make a call to tree_height function, find the height of the tree
// Parameter: none
// Return: an integer, the height of the tree
int BinarySearchTree::tree_height() const
{
        return tree_height(root);
}

// tree_height
// Purpose: find the height of the tree
// Parameter: a pointer to a node 
// Return: an integer, the height of the tree
int BinarySearchTree::tree_height(Node *node) const
{
        if (node == nullptr){
            return -1;
        }
        if (node->right == nullptr and node->left == nullptr){
            return 0;
        } else {
            return 1 + max(tree_height(node->left), tree_height(node->right));
        }
}

// node_count
// Purpose: make a call to tree_height function, find the height of the tree
// Parameter: none
// Return: an integer, the total number of nodes
int BinarySearchTree::node_count() const
{
        return node_count(root);
}

// node_count
// Purpose: find the height of the tree
// Parameter: a pointer to a node 
// Return: an integer, the total number of nodes
int BinarySearchTree::node_count(Node *node) const
{
        if (node == nullptr){
            return 0;
        }
        return 1 + node_count(node->left) + node_count(node->right);
    
}

// count_total
// Purpose: find the height of the tree
// Parameter: none
// Return: the sum of all the node values (including duplicates)
int BinarySearchTree::count_total() const
{
        return count_total(root);
}

// count_total
// Purpose: find the height of the tree
// Parameter: the pointer to a node
// Return: the sum of all the node values (including duplicates)
int BinarySearchTree::count_total(Node *node) const
{
        if (node == nullptr){
            return 0;
        }
        
        return node->data * node->count + count_total(node->left) + 
        count_total(node->right);
}

// find_parent
// Purpose: find the parent of a node
// Parameter: the pointer to a node, and pointer to a child node
// Return: the parent node of the child node
BinarySearchTree::Node *BinarySearchTree::find_parent(Node *node,
                                                      Node *child) const
{
        if (node == nullptr)
                return nullptr;

        // if either the left or right is equal to the child,
        // we have found the parent
        if (node->left == child or node->right == child) {
                return node;
        }

        // Use the binary search tree invariant to walk the tree
        if (child->data > node->data) {
                return find_parent(node->right, child);
        } else {
                return find_parent(node->left, child);
        }
}

// use the printPretty helper to make the tree look nice
void BinarySearchTree::print_tree() const
{
        size_t      numLayers  = tree_height() + 1;
        size_t      levelWidth = 4;
        const char *rootPrefix = "-> ";

        // Need numLayers * levelWidth characters for each layer of tree.
        // Add an extra levelWidth characters at front to avoid if statement
        // 1 extra char for nul character at end
        char *start = new char[(numLayers + 1) * levelWidth + 1];

        print_tree(root, start + levelWidth, start + levelWidth, rootPrefix);
        delete[] start;
}

// Logic and Output Reference: 
// https://www.techiedelight.com/c-program-print-binary-tree/
void BinarySearchTree::print_tree(Node *node, char *const currPos,
                                  const char *const fullLine,
                                  const char *const branch) const
{
        if (node == nullptr)
                return;

        // 4 characters + 1 for nul terminator
        using TreeLevel                    = char[5];
        static const int       levelLength = sizeof(TreeLevel) - 1;
        static const TreeLevel UP = ".-- ", DOWN = "`-- ", EMPTY = "    ",
                               CONNECT = "   |";
        // Copies prev into dest and advances dest by strlen(prev)
        auto set = [](char *dest, const char *prev) {
                size_t p = strlen(prev);
                return (char *)memcpy(dest, prev, p) + p;
        };

        print_tree(node->right, set(currPos, EMPTY), fullLine, UP);

        // Clear any characters that would immediate precede the "branch"
        // Don't need to check for root (i.e start of array),fullLine is padded
        set(currPos - levelLength, EMPTY);

        // Terminate fullLine at current level
        *currPos = '\0';

        std::cerr << fullLine << branch << node->data
                  << (node->count > 1 ? "*" : "") << endl;

        // Connect upper branch to parent
        if (branch == UP)
                set(currPos - levelLength, CONNECT);

        // Connect lower branch to parent
        print_tree(node->left, set(currPos, CONNECT), fullLine, DOWN);
}
