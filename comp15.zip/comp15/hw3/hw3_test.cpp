/*
 * hw3_test.cpp
 *
 * by Irene Chang
 *    
 * Reference: hw3.cpp 
 * Purpose: Additional testing program for functions in BinarySearchTree class
 */

#include <iostream>

#include "BinarySearchTree.h"

using namespace std;

void print_tree_details(BinarySearchTree &bst)
{
        bst.print_tree();
        cout << "\n";
        cout << "min: "         << bst.find_min()    << "\n";
        cout << "max: "         << bst.find_max()    << "\n";
        cout << "nodes: "       << bst.node_count()  << "\n";
        cout << "count total: " << bst.count_total() << "\n";
        cout << "tree height: " << bst.tree_height() << "\n";
        cout << "\n";
}

int main()
{
        BinarySearchTree bst;
        int values[]  = {4, 2, 11, 15, 9, 1, -6, 5, 3, 15, 2, 5, 13, 14};
        int numValues = sizeof(values) / sizeof(int);

        for (int i = 0; i < numValues; i++) {
                bst.insert(values[i]);
        }
        cout << "Original tree "
             << "(asterisks denote a count of more than 1):\n";
        print_tree_details(bst);
        
        // make a copy with copy constructor
        BinarySearchTree bst_copy_constructor = bst;
        bst_copy_constructor.print_tree();
        
        // make a copy with assignment overload
        BinarySearchTree bst_copy_1;
        bst_copy_1 = bst;
        
        // remove a node with one child (but the count is 2)
        cout << "Removing 5 from original tree "
             << "(should still have one 5):\n";
        bst.remove(5);
        print_tree_details(bst);
        
        // check if the tree contains values
        bst = bst_copy_1;
        
        // remove a node with one child
        cout << "Removing 2 twice from original tree:\n";
        bst.remove(2);
        print_tree_details(bst);
        bst.remove(2);
        print_tree_details(bst);
        
        bst = bst_copy_1;
        
        cout << "Removing 15 twice from original tree:\n";
        bst.remove(15);
        print_tree_details(bst);
        bst.remove(15);
        print_tree_details(bst);
        
        bst = bst_copy_1;
        
        // remove the root for multiple times
        cout << "Removing the root:\n";
        bst.remove(4);
        print_tree_details(bst);
        cout << "Removing the root again:\n";
        bst.remove(5);
        bst.remove(5);
        print_tree_details(bst);
        cout << "Removing the root again:\n";
        bst.remove(9);
        print_tree_details(bst);
        cout << "Removing the root again:\n";
        bst.remove(11);
        print_tree_details(bst);
        cout << "Removing the root again:\n";
        bst.remove(13);
        print_tree_details(bst);
        cout << "Removing the root again:\n";
        bst.remove(14);
        print_tree_details(bst);
        cout << "Removing the root again:\n";
        bst.remove(15);
        bst.remove(15);
        print_tree_details(bst);
        
        bst = bst_copy_1;
        
        // further testing
        cout << "Insert 50:\n";
        bst.insert(50);
        print_tree_details(bst);
        cout << "Remove 14:\n";
        bst.remove(14);
        print_tree_details(bst);
        cout << "Remove 13:\n";
        bst.remove(13);
        print_tree_details(bst);
        cout << "Insert 12:\n";
        bst.insert(12);
        print_tree_details(bst);
        cout << "Insert 49 twice:\n";
        bst.insert(49);
        bst.insert(49);
        print_tree_details(bst);
        cout << "Insert 53:\n";
        bst.insert(53);
        print_tree_details(bst);
        // cout << "Remove 50:\n";
        // bst.remove(50);
        // print_tree_details(bst);
        cout << "Remove 11:\n";
        bst.remove(11);
        print_tree_details(bst);
        bst.remove(100); // remove a number not in the tree
        print_tree_details(bst);
        
        bst = bst_copy_1;
        
        return 0;
}
