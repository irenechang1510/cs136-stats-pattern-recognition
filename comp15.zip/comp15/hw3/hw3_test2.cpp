/*
 * hw3_test2.cpp
 *
 * by Irene Chang
 *    
 * Reference: hw3.cpp 
 * Purpose: Test an edge case in the program where we remove the root until the
 *          tree is empty by using a simple tree
 */
#include <iostream>

#include "BinarySearchTree.h"

using namespace std;

void print_tree_details(BinarySearchTree &bst)
{
        bst.print_tree();
        cout << "\n";
        cout << "min: "         << bst.find_min()    << "\n";
        cout << "max: "         << bst.find_max()    << "\n";
        cout << "nodes: "       << bst.node_count()  << "\n";
        cout << "count total: " << bst.count_total() << "\n";
        cout << "tree height: " << bst.tree_height() << "\n";
        cout << "\n";
}

int main()
{
        BinarySearchTree bst;
        int values[]  = {4, 2, 11};
        int numValues = sizeof(values) / sizeof(int);
        
        for (int i = 0; i < numValues; i++) {
                bst.insert(values[i]);
        }
        cout << "Original tree "
             << "(asterisks denote a count of more than 1):\n";
        print_tree_details(bst);
        cout << "Remove 4 - root: " << endl;
        bst.remove(4);
        print_tree_details(bst);
        cout << "Remove 11 - root: " << endl;
        bst.remove(11);
        print_tree_details(bst);
        cout << "Remove 2 - root: " << endl;
        bst.remove(2);
        print_tree_details(bst);
        
        return 0;
}